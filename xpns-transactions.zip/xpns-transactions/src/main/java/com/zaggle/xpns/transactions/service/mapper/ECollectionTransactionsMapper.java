package com.zaggle.xpns.transactions.service.mapper;

import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.domain.ECollectionTransactions;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsDTO;
import com.zaggle.xpns.transactions.service.dto.ECollectionTransactionsDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ECollectionTransactionsMapper extends EntityMapper<CardTransactionsDTO, CardTransactions>{
    ECollectionTransactions toEntity(ECollectionTransactionsDTO eCollectionTransactionsDTO);

    ECollectionTransactions toDto(ECollectionTransactions eCollectionTransaction);
}
