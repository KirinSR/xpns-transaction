package com.zaggle.xpns.transactions.domain;

import com.zaggle.xpns.transactions.service.dto.ECollectionTransactionsDTO;
import lombok.*;
//import org.h2.util.json.JSONObject;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.Instant;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Getter
@Setter
@Table(name = "ecollection_transactions")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class ECollectionTransactions implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGeneratorEcollectionTransactions")
    @SequenceGenerator(name = "sequenceGeneratorEcollectionTransactions",allocationSize = 1,initialValue = 1)
    @Column(name = "id")
    private Long id;
//    @Column(name="response_code")
//    private String responseCode;
//    @Column(name="transaction_status")
//    private String transactionStatus;
    @Column(name="request_id")
    private String requestId;
    @Column(name="challan_code")
    private String challanCode;
    @Column(name="challan_no")
    private String challanNo;
    @Column(name="client_account_no")
    private String clientAccountNo;
    @Column(name="client_name")
    private String clientName;
    @Column(name="amount")
    private BigDecimal amount;
    @Column(name="remitter_name")
    private String remitterName;

    @Column(name="remitter_account_no")
    private String remitterAccountNo;
    @Column(name="remitter_IFSC")
    private String remitterIFSC;
    @Column(name="remitter_bank")
    private String remitterBank;
    @Column(name="remitter_branch")
    private String remitterBranch;
    @Column(name="remitter_UTR")
    private String remitterUTR;
    @Column(name="pay_method")
    private String payMethod;

    @Column(name="inward_ref_num")
    private String inwardRefNum;
    @Column(name="credit_time")
    private String creditTime;
    @Column(name="credit_account_no")
    private String creditAccountNo;

    @Column(name="org_id")
    private String orgId;
    @Column(name="reserve1")
    private String reserve1;
    @Column(name="reserve2")
    private String reserve2;
    @Column(name="reserve3")
    private String reserve3;
    @Column(name="reserve4")
    private String reserve4;
    @Type(type = "jsonb")
    @Column(name="json_info", columnDefinition = "json")
    private ECollectionTransactionsDTO json_info;

    @Column(name="balance")
    private Double balance;



    @CreatedDate
    @Column(name = "created_dt", updatable = false)
    private Instant createdDt;
    @CreatedBy
    @Column(name = "created_by", updatable = false)
    private String createdBy;
//    @LastModifiedBy
//    @Column(name = "updated_by", length = 50)
//    private String updatedBy;
//    @LastModifiedDate
//    @Column(name = "updated_dt")
//    private Instant updatedDt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

//    public String getResponseCode() {
//        return responseCode;
//    }
//
//    public void setResponseCode(String responseCode) {
//        this.responseCode = responseCode;
//    }
//
//    public String getTransactionStatus() {
//        return transactionStatus;
//    }
//
//    public void setTransactionStatus(String transactionStatus) {
//        this.transactionStatus = transactionStatus;
//    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getChallanCode() {
        return challanCode;
    }

    public void setChallanCode(String challanCode) {
        this.challanCode = challanCode;
    }

    public String getChallanNo() {
        return challanNo;
    }

    public void setChallanNo(String challanNo) {
        this.challanNo = challanNo;
    }

    public String getClientAccountNo() {
        return clientAccountNo;
    }

    public void setClientAccountNo(String clientAccountNo) {
        this.clientAccountNo = clientAccountNo;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRemitterName() {
        return remitterName;
    }

    public void setRemitterName(String remitterName) {
        this.remitterName = remitterName;
    }

    public String getRemitterAccountNo() {
        return remitterAccountNo;
    }

    public void setRemitterAccountNo(String remitterAccountNo) {
        this.remitterAccountNo = remitterAccountNo;
    }

    public String getRemitterIFSC() {
        return remitterIFSC;
    }

    public void setRemitterIFSC(String remitterIFSC) {
        this.remitterIFSC = remitterIFSC;
    }

    public String getRemitterBank() {
        return remitterBank;
    }

    public void setRemitterBank(String remitterBank) {
        this.remitterBank = remitterBank;
    }

    public String getRemitterBranch() {
        return remitterBranch;
    }

    public void setRemitterBranch(String remitterBranch) {
        this.remitterBranch = remitterBranch;
    }

    public String getRemitterUTR() {
        return remitterUTR;
    }

    public void setRemitterUTR(String remitterUTR) {
        this.remitterUTR = remitterUTR;
    }

    public String getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }

    public String getInwardRefNum() {
        return inwardRefNum;
    }

    public void setInwardRefNum(String inwardRefNum) {
        this.inwardRefNum = inwardRefNum;
    }

    public String getCreditTime() {
        return creditTime;
    }

    public void setCreditTime(String creditTime) {
        this.creditTime = creditTime;
    }

    public String getCreditAccountNo() {
        return creditAccountNo;
    }

    public void setCreditAccountNo(String creditAccountNo) {
        this.creditAccountNo = creditAccountNo;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getReserve1() {
        return reserve1;
    }

    public void setReserve1(String reserve1) {
        this.reserve1 = reserve1;
    }

    public String getReserve2() {
        return reserve2;
    }

    public void setReserve2(String reserve2) {
        this.reserve2 = reserve2;
    }

    public String getReserve3() {
        return reserve3;
    }

    public void setReserve3(String reserve3) {
        this.reserve3 = reserve3;
    }

    public String getReserve4() {
        return reserve4;
    }

    public void setReserve4(String reserve4) {
        this.reserve4 = reserve4;
    }

    public ECollectionTransactionsDTO getJson_info() {
        return json_info;
    }

    public void setJson_info(ECollectionTransactionsDTO json_info) {
        this.json_info = json_info;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public Instant getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Instant createdDt) {
        this.createdDt = createdDt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

//    public String getUpdatedBy() {
//        return updatedBy;
//    }
//
//    public void setUpdatedBy(String updatedBy) {
//        this.updatedBy = updatedBy;
//    }
//
//    public Instant getUpdatedDt() {
//        return updatedDt;
//    }
//
//    public void setUpdatedDt(Instant updatedDt) {
//        this.updatedDt = updatedDt;
//    }
}
