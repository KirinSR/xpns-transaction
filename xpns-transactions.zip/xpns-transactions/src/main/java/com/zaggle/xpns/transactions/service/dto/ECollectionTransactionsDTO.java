package com.zaggle.xpns.transactions.service.dto;

import lombok.*;
import org.json.simple.JSONObject;

import javax.json.Json;
import java.io.Serializable;
import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ECollectionTransactionsDTO implements Serializable {
//    private Long id;
    private String requestId;
    private String challanCode;
    private String challanNo;
    private String clientAccountNo;
    private String clientName;
    private BigDecimal amount;
    private String remitterName;
    private String remitterAccountNo;
    private String remitterIFSC;
    private String remitterBank;
    private String remitterBranch;
    private String remitterUTR;
    private String payMethod;
    private String inwardRefNum;
    private String creditTime;
    private String creditAccountNo;

    private String reserve1;
    private String reserve2;
    private String reserve3;
    private String reserve4;

}
