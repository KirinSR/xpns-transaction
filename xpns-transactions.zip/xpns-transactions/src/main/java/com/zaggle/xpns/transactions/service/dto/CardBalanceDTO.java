package com.zaggle.xpns.transactions.service.dto;

import java.time.Instant;
import java.util.Objects;

public class CardBalanceDTO {

    private Long id;
    private String entityId;
    private String kitNo;
    private String cardNo;
    private Double balance;
    private Instant createdDt;
    private String createdBy;
    private Instant updatedDt;
    private String updatedBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getKitNo() {
        return kitNo;
    }

    public void setKitNo(String kitNo) {
        this.kitNo = kitNo;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public Instant getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Instant createdDt) {
        this.createdDt = createdDt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Instant getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Instant updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CardBalanceDTO that = (CardBalanceDTO) o;
        return Objects.equals(id, that.id) && Objects.equals(entityId, that.entityId) && Objects.equals(kitNo, that.kitNo) && Objects.equals(cardNo, that.cardNo) && Objects.equals(balance, that.balance) && Objects.equals(createdDt, that.createdDt) && Objects.equals(createdBy, that.createdBy) && Objects.equals(updatedDt, that.updatedDt) && Objects.equals(updatedBy, that.updatedBy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, entityId, kitNo, cardNo, balance, createdDt, createdBy, updatedDt, updatedBy);
    }

    @Override
    public String toString() {
        return "CardBalanceDTO{" +
                "id=" + id +
                ", entityId='" + entityId + '\'' +
                ", kitNo='" + kitNo + '\'' +
                ", cardNo='" + cardNo + '\'' +
                ", balance=" + balance +
                ", createdDt=" + createdDt +
                ", createdBy='" + createdBy + '\'' +
                ", updatedDt=" + updatedDt +
                ", updatedBy='" + updatedBy + '\'' +
                '}';
    }
}
