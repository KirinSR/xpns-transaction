package com.zaggle.xpns.transactions.domain;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

import javax.persistence.*;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

/**
 * A CardTransactions.
 */
    
@NoArgsConstructor
@Builder
@Entity
@Getter
@Setter
@Table(name = "card_transactions")
@SuppressWarnings("common-java:DuplicatedBlocks")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardTransactions implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGeneratorCardTransactions")
	@SequenceGenerator(name = "sequenceGeneratorCardTransactions",allocationSize = 1,initialValue = 1)
	@Column(name = "id")
	private Long id;

	@Column(name = "entity_id")
	private String entityId;

	/**
	 * M2P’s transaction reference id
	 */
	@Column(name = "txn_ref")
	private String txnRefNo;

	@Column(name = "card_ref_no")
	private String cardRefNo;

	@Column(name = "card_kit_no")
	private String kitNo;

	@Column(name = "mobileNo")
	private String mobileNo;

	@Column(name = "card_type")
	private String cardType;

	@Column(name = "merchant_location")
	private String merchantLocation;

	@Column(name = "channel")
	private String channel;

	@Column(name = "txn_currency")
	private String txnCurrency;

	@Column(name = "acquirer_id")
	private String acquirerId;

	@Column(name = "network")
	private String network;

	@Column(name = "billing_currency")
	private String billingCurrency;

	@Column(name = "accq_institution_code")
	private String accqInstitutionCode;

	@Column(name = "corporate")
	private String corporate;

	/**
	 * Transaction amount
	 */

	@Column(name = "amount")
	private Double amount;

	/**
	 * Available balance in card
	 */

	@Column(name = "balance")
	private Double balance;

	/**
	 * Transaction type
	 */

	@Column(name = "transaction_type")
	private String transactionType;

	/**
	 * Credit or Debit
	 */
	@Column(name = "type")
	private String crdr;

	/**
	 * Transaction timestamp
	 */

	@Column(name = "txn_time")
	private Long transactionDateTime;

	/**
	 * Beneficiary’s name
	 */

	@Column(name = "beneficiary_name")
	private String beneficiaryName;

	/**
	 * Beneficiary’s type
	 */
	@Column(name = "beneficiary_type")
	private String beneficiaryType;

	/**
	 * Beneficiary’s entity id
	 */
	@Column(name = "beneficiary_id")
	private String beneficiaryId;

	/**
	 * Transaction description
	 */
	@Column(name = "description")
	private String description;

	/**
	 * Transaction channel (Ex: Mobile, Web etc)
	 */
	@Column(name = "txn_origin")
	private String txnOrigin;

	/**
	 * Beneficiary’s Name
	 */

	@Column(name = "other_party_name")
	private String otherPartyName;

	/**
	 * Beneficiary’s Id
	 */
	@Column(name = "other_party_id")
	private String otherPartyId;

	/**
	 * Transaction status
	 */

	@Column(name = "transaction_status")
	private String txnStatus;

	/**
	 * Customer’s wallet name
	 */
	@Column(name = "customer_wallet")
	private String customerWallet;

	/**
	 * Beneficiary’s wallet name
	 */
	@Column(name = "beneficiary_wallet")
	private String beneficiaryWallet;

	/**
	 * Customer’s unique external Transaction Id
	 */

	@Column(name = "external_transaction_id")
	private String extTxnId;

	/**
	 * Customer’s retrieval reference Number
	 */

	@Column(name = "retrival_reference_no")
	private String retrievalRefNo;

	/**
	 * Customer’s authorization Code
	 */

	@Column(name = "auth_code")
	private String authCode;

	/**
	 * Customer’s bill reference Number
	 */

	@Column(name = "bill_ref_no")
	private String billRefNo;

	/**
	 * Customer’s Bank Transaction Id
	 */

	@Column(name = "bank_tid")
	private String bankTid;


	@CreatedDate
	@Column(name = "created_dt")
	private Instant createdDt;

	@CreatedBy
	@Column(name = "created_by")
	private String createdBy;

	@LastModifiedBy
	@Column(name = "updated_by", length = 50)
	private String updatedBy;

	@LastModifiedDate
	@Column(name = "updated_dt")
	private Instant updatedDt;


	@Column(name="card_transactions_addn_info_id")
	private Long cardTransactionsAddnInfo;

	@OneToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	private CardTransactionAddnInfo jsonInfo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEntityId() {
		return entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getTxnRefNo() {
		return txnRefNo;
	}

	public void setTxnRefNo(String txnRefNo) {
		this.txnRefNo = txnRefNo;
	}

	public String getCardRefNo() {
		return cardRefNo;
	}

	public void setCardRefNo(String cardRefNo) {
		this.cardRefNo = cardRefNo;
	}

	public String getKitNo() {
		return kitNo;
	}

	public void setKitNo(String kitNo) {
		this.kitNo = kitNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getMerchantLocation() {
		return merchantLocation;
	}

	public void setMerchantLocation(String merchantLocation) {
		this.merchantLocation = merchantLocation;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getTxnCurrency() {
		return txnCurrency;
	}

	public void setTxnCurrency(String txnCurrency) {
		this.txnCurrency = txnCurrency;
	}

	public String getAcquirerId() {
		return acquirerId;
	}

	public void setAcquirerId(String acquirerId) {
		this.acquirerId = acquirerId;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public String getBillingCurrency() {
		return billingCurrency;
	}

	public void setBillingCurrency(String billingCurrency) {
		this.billingCurrency = billingCurrency;
	}

	public String getAccqInstitutionCode() {
		return accqInstitutionCode;
	}

	public void setAccqInstitutionCode(String accqInstitutionCode) {
		this.accqInstitutionCode = accqInstitutionCode;
	}

	public String getCorporate() {
		return corporate;
	}

	public void setCorporate(String corporate) {
		this.corporate = corporate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getCrdr() {
		return crdr;
	}

	public void setCrdr(String crdr) {
		this.crdr = crdr;
	}

	public Long getTransactionDateTime() {
		return transactionDateTime;
	}

	public void setTransactionDateTime(Long transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public String getBeneficiaryType() {
		return beneficiaryType;
	}

	public void setBeneficiaryType(String beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}

	public String getBeneficiaryId() {
		return beneficiaryId;
	}

	public void setBeneficiaryId(String beneficiaryId) {
		this.beneficiaryId = beneficiaryId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTxnOrigin() {
		return txnOrigin;
	}

	public void setTxnOrigin(String txnOrigin) {
		this.txnOrigin = txnOrigin;
	}

	public String getOtherPartyName() {
		return otherPartyName;
	}

	public void setOtherPartyName(String otherPartyName) {
		this.otherPartyName = otherPartyName;
	}

	public String getOtherPartyId() {
		return otherPartyId;
	}

	public void setOtherPartyId(String otherPartyId) {
		this.otherPartyId = otherPartyId;
	}

	public String getTxnStatus() {
		return txnStatus;
	}

	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	public String getCustomerWallet() {
		return customerWallet;
	}

	public void setCustomerWallet(String customerWallet) {
		this.customerWallet = customerWallet;
	}

	public String getBeneficiaryWallet() {
		return beneficiaryWallet;
	}

	public void setBeneficiaryWallet(String beneficiaryWallet) {
		this.beneficiaryWallet = beneficiaryWallet;
	}

	public String getExtTxnId() {
		return extTxnId;
	}

	public void setExtTxnId(String extTxnId) {
		this.extTxnId = extTxnId;
	}

	public String getRetrievalRefNo() {
		return retrievalRefNo;
	}

	public void setRetrievalRefNo(String retrievalRefNo) {
		this.retrievalRefNo = retrievalRefNo;
	}

	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public String getBankTid() {
		return bankTid;
	}

	public void setBankTid(String bankTid) {
		this.bankTid = bankTid;
	}

	public Instant getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Instant createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Instant getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Instant updatedDt) {
		this.updatedDt = updatedDt;
	}

	public Long getCardTransactionsAddnInfo() {
		return cardTransactionsAddnInfo;
	}

	public void setCardTransactionsAddnInfo(Long cardTransactionsAddnInfo) {
		this.cardTransactionsAddnInfo = cardTransactionsAddnInfo;
	}

	public CardTransactionAddnInfo getJsonInfo() {
		return jsonInfo;
	}

	public void setJsonInfo(CardTransactionAddnInfo jsonInfo) {
		this.jsonInfo = jsonInfo;
	}

	public CardTransactions(Long id, String entityId, String txnRefNo, String cardRefNo, String kitNo, String mobileNo, String cardType, String merchantLocation, String channel, String txnCurrency, String acquirerId, String network, String billingCurrency, String accqInstitutionCode, String corporate, Double amount, Double balance, String transactionType, String crdr, Long transactionDateTime, String beneficiaryName, String beneficiaryType, String beneficiaryId, String description, String txnOrigin, String otherPartyName, String otherPartyId, String txnStatus, String customerWallet, String beneficiaryWallet, String extTxnId, String retrievalRefNo, String authCode, String billRefNo, String bankTid, Instant createdDt, String createdBy, String updatedBy, Instant updatedDt, Long cardTransactionsAddnInfo, CardTransactionAddnInfo jsonInfo) {
		this.id = id;
		this.entityId = entityId;
		this.txnRefNo = txnRefNo;
		this.cardRefNo = cardRefNo;
		this.kitNo = kitNo;
		this.mobileNo = mobileNo;
		this.cardType = cardType;
		this.merchantLocation = merchantLocation;
		this.channel = channel;
		this.txnCurrency = txnCurrency;
		this.acquirerId = acquirerId;
		this.network = network;
		this.billingCurrency = billingCurrency;
		this.accqInstitutionCode = accqInstitutionCode;
		this.corporate = corporate;
		this.amount = amount;
		this.balance = balance;
		this.transactionType = transactionType;
		this.crdr = crdr;
		this.transactionDateTime = transactionDateTime;
		this.beneficiaryName = beneficiaryName;
		this.beneficiaryType = beneficiaryType;
		this.beneficiaryId = beneficiaryId;
		this.description = description;
		this.txnOrigin = txnOrigin;
		this.otherPartyName = otherPartyName;
		this.otherPartyId = otherPartyId;
		this.txnStatus = txnStatus;
		this.customerWallet = customerWallet;
		this.beneficiaryWallet = beneficiaryWallet;
		this.extTxnId = extTxnId;
		this.retrievalRefNo = retrievalRefNo;
		this.authCode = authCode;
		this.billRefNo = billRefNo;
		this.bankTid = bankTid;
		this.createdDt = createdDt;
		this.createdBy = createdBy;
		this.updatedBy = updatedBy;
		this.updatedDt = updatedDt;
		this.cardTransactionsAddnInfo = cardTransactionsAddnInfo;
		this.jsonInfo = jsonInfo;
	}

	@Override
	public String toString() {
		return "CardTransactions{" +
				"id=" + id +
				", txnRefNo='" + txnRefNo + '\'' +
				", cardRefNo='" + cardRefNo + '\'' +
				", kitNo='" + kitNo + '\'' +
				", mobileNo='" + mobileNo + '\'' +
				", cardType='" + cardType + '\'' +
				", merchantLocation='" + merchantLocation + '\'' +
				", channel='" + channel + '\'' +
				", txnCurrency='" + txnCurrency + '\'' +
				", acquirerId='" + acquirerId + '\'' +
				", network='" + network + '\'' +
				", billingCurrency='" + billingCurrency + '\'' +
				", accqInstitutionCode='" + accqInstitutionCode + '\'' +
				", corporate='" + corporate + '\'' +
				", amount=" + amount +
				", balance=" + balance +
				", transactionType='" + transactionType + '\'' +
				", crdr='" + crdr + '\'' +
				", transactionDateTime=" + transactionDateTime +
				", beneficiaryName='" + beneficiaryName + '\'' +
				", beneficiaryType='" + beneficiaryType + '\'' +
				", beneficiaryId='" + beneficiaryId + '\'' +
				", description='" + description + '\'' +
				", txnOrigin='" + txnOrigin + '\'' +
				", otherPartyName='" + otherPartyName + '\'' +
				", otherPartyId='" + otherPartyId + '\'' +
				", txnStatus='" + txnStatus + '\'' +
				", customerWallet='" + customerWallet + '\'' +
				", beneficiaryWallet='" + beneficiaryWallet + '\'' +
				", extTxnId='" + extTxnId + '\'' +
				", retrievalRefNo='" + retrievalRefNo + '\'' +
				", authCode='" + authCode + '\'' +
				", billRefNo='" + billRefNo + '\'' +
				", bankTid='" + bankTid + '\'' +
				", createdDt=" + createdDt +
				", createdBy='" + createdBy + '\'' +
				", updatedBy='" + updatedBy + '\'' +
				", updatedDt=" + updatedDt +
				", cardTransactionsAddnInfo=" + cardTransactionsAddnInfo +
				", jsonInfo=" + jsonInfo +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		CardTransactions that = (CardTransactions) o;
		return Objects.equals(id, that.id) && Objects.equals(txnRefNo, that.txnRefNo) && Objects.equals(cardRefNo, that.cardRefNo) && Objects.equals(kitNo, that.kitNo) && Objects.equals(mobileNo, that.mobileNo) && Objects.equals(cardType, that.cardType) && Objects.equals(merchantLocation, that.merchantLocation) && Objects.equals(channel, that.channel) && Objects.equals(txnCurrency, that.txnCurrency) && Objects.equals(acquirerId, that.acquirerId) && Objects.equals(network, that.network) && Objects.equals(billingCurrency, that.billingCurrency) && Objects.equals(accqInstitutionCode, that.accqInstitutionCode) && Objects.equals(corporate, that.corporate) && Objects.equals(amount, that.amount) && Objects.equals(balance, that.balance) && Objects.equals(transactionType, that.transactionType) && Objects.equals(crdr, that.crdr) && Objects.equals(transactionDateTime, that.transactionDateTime) && Objects.equals(beneficiaryName, that.beneficiaryName) && Objects.equals(beneficiaryType, that.beneficiaryType) && Objects.equals(beneficiaryId, that.beneficiaryId) && Objects.equals(description, that.description) && Objects.equals(txnOrigin, that.txnOrigin) && Objects.equals(otherPartyName, that.otherPartyName) && Objects.equals(otherPartyId, that.otherPartyId) && Objects.equals(txnStatus, that.txnStatus) && Objects.equals(customerWallet, that.customerWallet) && Objects.equals(beneficiaryWallet, that.beneficiaryWallet) && Objects.equals(extTxnId, that.extTxnId) && Objects.equals(retrievalRefNo, that.retrievalRefNo) && Objects.equals(authCode, that.authCode) && Objects.equals(billRefNo, that.billRefNo) && Objects.equals(bankTid, that.bankTid) && Objects.equals(createdDt, that.createdDt) && Objects.equals(createdBy, that.createdBy) && Objects.equals(updatedBy, that.updatedBy) && Objects.equals(updatedDt, that.updatedDt) && Objects.equals(cardTransactionsAddnInfo, that.cardTransactionsAddnInfo) && Objects.equals(jsonInfo, that.jsonInfo);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, txnRefNo, cardRefNo, kitNo, mobileNo, cardType, merchantLocation, channel, txnCurrency, acquirerId, network, billingCurrency, accqInstitutionCode, corporate, amount, balance, transactionType, crdr, transactionDateTime, beneficiaryName, beneficiaryType, beneficiaryId, description, txnOrigin, otherPartyName, otherPartyId, txnStatus, customerWallet, beneficiaryWallet, extTxnId, retrievalRefNo, authCode, billRefNo, bankTid, createdDt, createdBy, updatedBy, updatedDt, cardTransactionsAddnInfo, jsonInfo);
	}
}
