package com.zaggle.xpns.transactions.service;

import com.zaggle.xpns.transactions.service.dto.CardBalanceDTO;
import com.zaggle.xpns.transactions.service.dto.CardBalanceResponseDTO;

import java.util.Optional;

public interface CardBalanceService {

    CardBalanceDTO save(CardBalanceDTO cardBalanceDTO);

    Optional<CardBalanceResponseDTO> findOne(Long id);
    Optional<CardBalanceDTO> update(CardBalanceDTO cardBalanceDTO);

}
