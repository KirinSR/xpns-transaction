package com.zaggle.xpns.transactions.service.dto;

import lombok.*;

import java.math.BigDecimal;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CreditBalanceDTO {

    private String orgId;
    private String descreption;
    private BigDecimal amount;
    private String type;

//    public String getOrgId() {
//        return orgId;
//    }
//
//    public void setOrgId(String orgId) {
//        this.orgId = orgId;
//    }
//
//    public String getDescreption() {
//        return descreption;
//    }
//
//    public void setDescreption(String descreption) {
//        this.descreption = descreption;
//    }
//
//    public BigDecimal getAmount() {
//        return amount;
//    }
//
//    public void setAmount(BigDecimal amount) {
//        this.amount = amount;
//    }
//
//    public String getType() {
//        return type;
//    }
//
//    public void setType(String type) {
//        this.type = type;
//    }
}
