package com.zaggle.xpns.transactions.web.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.xpns.transactions.config.TimeTraker;
import com.zaggle.xpns.transactions.domain.ECollectionTransactions;
import com.zaggle.xpns.transactions.repository.EcollectionTransactionsRepository;
import com.zaggle.xpns.transactions.service.ECollectionTransactionsService;
import com.zaggle.xpns.transactions.service.dto.*;
import com.zaggle.xpns.transactions.service.mapper.ECollectionTransactionsMapper;
import com.zaggle.xpns.transactions.util.XpnsHeaderUtil;
import com.zaggle.xpns.transactions.web.rest.errors.BadRequestAlertException;
import org.json.HTTP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class EcollectionTransactionsResource {
    private final Logger log = LoggerFactory.getLogger(CardTransactionsResource.class);

    private static final String ENTITY_NAME = "transactionsECollectionTransactions";

    @Value("${xpns.clientApp.name}")
    private String applicationName;

    private final EcollectionTransactionsRepository ecollectionTransactionsRepository;
    private final ECollectionTransactionsMapper eCollectionTransactionsMapper;
    private final ECollectionTransactionsService eCollectionTransactionsService;

    public EcollectionTransactionsResource(EcollectionTransactionsRepository ecollectionTransactionsRepository, ECollectionTransactionsMapper eCollectionTransactionsMapper, ECollectionTransactionsService eCollectionTransactionsService) {
        this.ecollectionTransactionsRepository = ecollectionTransactionsRepository;
        this.eCollectionTransactionsMapper = eCollectionTransactionsMapper;
        this.eCollectionTransactionsService = eCollectionTransactionsService;
    }

    @PostMapping("/ecollection-transactions")
    @TimeTraker
    public ResponseEntity<TransactionApiResponse> createEcollectionTransactions(@Valid @RequestBody ECollectionTransactionsDTO eCollectionTransactionsDTO)
            throws URISyntaxException, JsonProcessingException {
        log.info("REST request to save ECollection : {}", eCollectionTransactionsDTO);

        ECollectionTransactions result = eCollectionTransactionsService.save(eCollectionTransactionsDTO);
//        System.out.println(result.getId());
        log.info("Ecollection Transaction Saved: ", result);
        return ResponseEntity
                .created(new URI("/api/ecollection-transactions/" + result.getId()))
                .headers(XpnsHeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
                .body(new TransactionApiResponse("","Transaction created", HttpStatus.CREATED.value()));
    }

    @GetMapping("/ecollection-transactions")
    @TimeTraker
    public ResponseEntity<List<ECollectionTransactions>> getAllEcollectionTransactions(@RequestParam(value = "pageNo", defaultValue = "0",
            required = false) int pageNo,
                                                                                       @RequestParam(value = "pageSize", defaultValue = "10",
                                                                                               required = false) int pageSize,
                                                                                       @RequestParam(value = "sortBy", defaultValue = "id",
                                                                                               required = false) String sortBy,
                                                                                       @RequestParam(value = "sortOrder", defaultValue = "asc",
                                                                                               required = false) String sortOrder,@RequestHeader("Authorization") String bearerToken) throws JsonProcessingException {
        log.info("REST request to get page of ECollections ");
        String token = bearerToken.split(" ")[1].trim();
        String[] chunks = token.split("\\.");
        Base64.Decoder decoder = Base64.getUrlDecoder();

//    String header = new String(decoder.decode(chunks[0]));
        String payload = new String(decoder.decode(chunks[1]));
        Pageable pageRequest = PageRequest.of(pageNo, pageSize,
                Sort.by(new Sort.Order(Sort.Direction.fromString(sortOrder), sortBy)));
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode node = objectMapper.readValue(payload, JsonNode.class);
        String email=node.get("email").asText();
        String tenantId=node.get("orgId").asText();
        List<ECollectionTransactions> transactions = eCollectionTransactionsService.getAllByOrgId(pageRequest, tenantId);
        return ResponseEntity.ok(transactions);
    }


    @GetMapping("/ecollection-transactions/getLinkedAccStatus")
    @TimeTraker
    public ResponseEntity<List<LinkedBankAccountStatus>> getLinkedBankAccountStatus(@RequestParam(value = "pageNo", defaultValue = "0",
            required = false) int pageNo,
                                                                                    @RequestParam(value = "pageSize", defaultValue = "10",
                                                                                            required = false) int pageSize,
                                                                                    @RequestParam(value = "sortBy", defaultValue = "id",
                                                                                            required = false) String sortBy,
                                                                                    @RequestParam(value = "sortOrder", defaultValue = "asc",
                                                                                            required = false) String sortOrder,@RequestHeader("Authorization") String bearerToken) throws JsonProcessingException {
        String token = bearerToken.split(" ")[1].trim();
        String[] chunks = token.split("\\.");
        Base64.Decoder decoder = Base64.getUrlDecoder();

//    String header = new String(decoder.decode(chunks[0]));
        String payload = new String(decoder.decode(chunks[1]));
        Pageable pageRequest = PageRequest.of(pageNo, pageSize,
                Sort.by(new Sort.Order(Sort.Direction.fromString(sortOrder), sortBy)));
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode node = objectMapper.readValue(payload, JsonNode.class);
        String email=node.get("email").asText();
        String tenantId=node.get("orgId").asText();
        log.info(" REST request to get LinkedAccountStatus ");
        List<ECollectionTransactions> transactions = eCollectionTransactionsService.getAllByOrgId(pageRequest ,tenantId);

        List<LinkedBankAccountStatus> statusList = new ArrayList<>();
        for (ECollectionTransactions transaction : transactions){
            LinkedBankAccountStatus status = new LinkedBankAccountStatus();
            status.setIfscCode(transaction.getRemitterIFSC());
            status.setAccountNumber(transaction.getClientAccountNo());
            status.setBeneficiaryName(transaction.getRemitterName());
            statusList.add(status);
        }
        return ResponseEntity.ok(statusList);
    }

    @GetMapping(value="/download/ecollectionReport")
    public ResponseEntity<byte[]> generateEcollectionReport(){
        byte[] file = eCollectionTransactionsService.generateEcollectionReport();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=Ecollection_Report"+ LocalDateTime.now()+".csv");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_OCTET_STREAM).body(file);
    }

}



