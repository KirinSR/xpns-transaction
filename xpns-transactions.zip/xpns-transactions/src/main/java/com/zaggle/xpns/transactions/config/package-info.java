/**
 * Spring Framework configuration files.
 */
package com.zaggle.xpns.transactions.config;
