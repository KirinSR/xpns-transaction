package com.zaggle.xpns.transactions.repository;

import com.zaggle.xpns.transactions.domain.CardBalance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface CardBalanceRepository extends JpaRepository<CardBalance, Long>, JpaSpecificationExecutor<CardBalance> {
}
