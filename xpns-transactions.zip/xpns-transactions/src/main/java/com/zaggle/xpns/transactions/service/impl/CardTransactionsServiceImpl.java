package com.zaggle.xpns.transactions.service.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.repository.CardTransactionsRepository;
import com.zaggle.xpns.transactions.service.CardTransactionsService;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsDTO;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsRequestDTO;
import com.zaggle.xpns.transactions.service.dto.TransactionApiResponse;
import com.zaggle.xpns.transactions.service.mapper.CardTransactionsMapper;

import java.lang.reflect.Field;
import java.time.Instant;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;

/**
 * Service Implementation for managing {@link CardTransactions}.
 */
@Service
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardTransactionsServiceImpl implements CardTransactionsService {

    private final Logger log = LoggerFactory.getLogger(CardTransactionsServiceImpl.class);

    private final CardTransactionsRepository cardTransactionsRepository;

    private final CardTransactionsMapper cardTransactionsMapper;

    public CardTransactionsServiceImpl(
        CardTransactionsRepository cardTransactionsRepository,
        CardTransactionsMapper cardTransactionsMapper
    ) {
        this.cardTransactionsRepository = cardTransactionsRepository;
        this.cardTransactionsMapper = cardTransactionsMapper;
    }

    @Override
    public CardTransactionsDTO save(CardTransactionsRequestDTO cardTransactionsReqDTO) {
        log.info("Request to save CardTransactions : {}", cardTransactionsReqDTO);

        CardTransactions cardTransactions = cardTransactionsMapper.toEntity(cardTransactionsReqDTO);
        cardTransactions.setCreatedDt(Instant.now());
        cardTransactions = cardTransactionsRepository.save(cardTransactions);
        System.out.println(""+cardTransactions.getCreatedDt());
        return cardTransactionsMapper.toDto(cardTransactions);

    }

    @Override
    public CardTransactionsDTO update(CardTransactionsDTO cardTransactionsDTO) {
        log.info("Request to update CardTransactions : {}", cardTransactionsDTO);
        String updatedBy = cardTransactionsDTO.getUpdatedBy();
        cardTransactionsDTO.setUpdatedDt(Instant.now());
        cardTransactionsDTO.setUpdatedBy(updatedBy);
        CardTransactions cardTransactions = cardTransactionsMapper.toEntity(cardTransactionsDTO);
        cardTransactions = cardTransactionsRepository.save(cardTransactions);
        return cardTransactionsMapper.toDto(cardTransactions);
    }

    @Override
    public Optional<CardTransactionsDTO> partialUpdate(CardTransactionsDTO cardTransactionsDTO) throws JsonProcessingException {
        log.info("Request to partially update CardTransactions : {}", cardTransactionsDTO);
        String updatedBy = cardTransactionsDTO.getUpdatedBy();
        cardTransactionsDTO.setUpdatedBy("ZIG");
        cardTransactionsDTO.setUpdatedDt(Instant.now());

        return cardTransactionsRepository
            .findById(cardTransactionsDTO.getId())
            .map(existingCardTransactions -> {
                cardTransactionsMapper.partialUpdate(existingCardTransactions, cardTransactionsDTO);

                return existingCardTransactions;
            })
            .map(cardTransactionsRepository::save)
            .map(cardTransactionsMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CardTransactionsDTO> findAll(Pageable pageable) {
        log.info("Request to get all CardTransactions");
        return cardTransactionsRepository.findAll(pageable).map(cardTransactionsMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<CardTransactionsDTO> findOne(Long id) {
        log.info("Request to get CardTransactions : {}", id);
        return cardTransactionsRepository.findById(id).map(cardTransactionsMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.info("Request to delete CardTransactions : {}", id);
        cardTransactionsRepository.deleteById(id);
    }

    @Override
    public List<CardTransactions> findAllTransactionsByKitNo(Pageable pageable, String kitNo) {
        log.info("Request to get all CardTransactions by : {}", kitNo);
        List<CardTransactions> transactions = cardTransactionsRepository.findAllByCardKitNo(pageable, kitNo);
        return transactions;
    }

    @Override
    public List<CardTransactions> findAllTransactionsByKitNoInRange(String kitNo) {
        log.info("Request to get all CardTransactions by : {}", kitNo);
        List<CardTransactions> transactions = cardTransactionsRepository.findAllByKitNoInRange(kitNo, LocalDate.now()).orElseThrow(() -> {
            throw new EntityNotFoundException("kitNo not found: "+kitNo);
        });
        return transactions;
    }

    @Override
    public TransactionApiResponse saveWebhook(Map<String, Object> requestBody) throws JsonProcessingException {
        CardTransactions cardTransaction = new CardTransactions();
        CardTransactionAddnInfo cardTransactionAddlInfo = new CardTransactionAddnInfo();
        Map<String, Object> unmappedFields = new HashMap<>();
        JSONObject jsonObject = new JSONObject();
        unmappedFields.put("empty", false);
        for (Map.Entry<String, Object> entry : requestBody.entrySet()) {
            String fieldName = entry.getKey();
            Object fieldValue = entry.getValue();
            try {
                Field field = cardTransaction.getClass().getDeclaredField(fieldName);
                field.setAccessible(true);
                if(fieldName.equals("amount") || fieldName.equals("balance"))
                    fieldValue=Double.parseDouble(fieldValue.toString());
                else if(fieldName.equals("transactionDateTime"))
                    fieldValue=Long.parseLong(fieldValue.toString());
                field.set(cardTransaction, fieldValue);
            } catch (NoSuchFieldException e) {
                unmappedFields.put(fieldName, fieldValue);
                jsonObject.put(fieldName, fieldValue);
            }
            catch (IllegalAccessException e){
                e.printStackTrace();
            }
        }
        unmappedFields.remove("empty");
        cardTransactionAddlInfo.setJsonInfo(jsonObject);
        cardTransaction.setJsonInfo(cardTransactionAddlInfo);
        cardTransaction.setCreatedDt(Instant.now());
        cardTransaction.setCreatedBy("ZIG");
        CardTransactions cardTransactions = cardTransactionsRepository.save(cardTransaction);
        return new TransactionApiResponse("", "Success", HttpStatus.CREATED.value());
    }
}
