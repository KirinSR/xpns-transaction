package com.zaggle.xpns.transactions.config;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.zaggle.xpns.transactions.constant.TransactionsConstants;



@Configuration
@Profile(TransactionsConstants.SPRING_PROFILE_API_DOCS)
public class OpenApiConfiguration {

    public static final String API_FIRST_PACKAGE = "com.zaggle.xpns.transactions.web.api";
    String defaultIncludePattern = "/api/**";
    @Bean
    @ConditionalOnMissingBean(name = "apiFirstGroupedOpenAPI")
    public GroupedOpenApi apiFirstGroupedOpenAPI(
    		XpnsApiCustomizer xpnsApiCustomizer
       
    ) {
       
        return GroupedOpenApi
            .builder()
            .group("openapi")
            .addOpenApiCustomiser(xpnsApiCustomizer)
            .packagesToScan(API_FIRST_PACKAGE)
            .pathsToMatch(defaultIncludePattern)
            .build();
    }
}
