package com.zaggle.xpns.transactions.service.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.util.Objects;

public class CardDetailsDTO {
    private Long id;

    private Integer cardId;

    private String empUserId;

    @NotNull
    private String orgId;

//    private CardStatus status;

    private Boolean isAssinged;

    @Size(min = 3, max = 40)
    private String entityId;

    @Size(min = 3, max = 20)
    private String createdBy;

    private LocalDate createdDt;

    private LocalDate updatedDt;

    @Size(min = 3, max = 20)
    private String updatedBy;

//    private CardInventoryDTO cardInventory;

    private Long cardInventoryId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getCardId() {
        return cardId;
    }

    public void setCardId(Integer cardId) {
        this.cardId = cardId;
    }

    public String getEmpUserId() {
        return empUserId;
    }

    public void setEmpUserId(String empUserId) {
        this.empUserId = empUserId;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

//    public CardStatus getStatus() {
//        return status;
//    }
//
//    public void setStatus(CardStatus status) {
//        this.status = status;
//    }

    public Boolean getIsAssinged() {
        return isAssinged;
    }

    public void setIsAssinged(Boolean isAssinged) {
        this.isAssinged = isAssinged;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDate getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(LocalDate createdDt) {
        this.createdDt = createdDt;
    }

    public LocalDate getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(LocalDate updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

//    public CardInventoryDTO getCardInventory() {
//        return cardInventory;
//    }

//    public void setCardInventory(CardInventoryDTO cardInventory) {
//        this.cardInventory = cardInventory;
//    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof CardDetailsDTO)) {
            return false;
        }

        CardDetailsDTO cardOrgEmployeeAssociationDTO = (CardDetailsDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, cardOrgEmployeeAssociationDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "CardOrgEmployeeAssociationDTO{" + "id=" + getId() + ", cardId=" + getCardId() + ", empUserId='"
                + getEmpUserId() + "'" + ", orgId='" + getOrgId() + "'"
                + ", isAssinged='" + getIsAssinged() + "'" + ", entityId='" + getEntityId() + "'" + ", createdBy='"
                + getCreatedBy() + "'" + ", createdDt='" + getCreatedDt() + "'" + ", updatedDt='" + getUpdatedDt() + "'"
                + ", updatedBy='" + getUpdatedBy() + "}";
    }

    public Long getCardInventoryId() {
        return cardInventoryId;
    }

    public void setCardInventoryId(Long cardInventoryId) {
        this.cardInventoryId = cardInventoryId;
    }
}
