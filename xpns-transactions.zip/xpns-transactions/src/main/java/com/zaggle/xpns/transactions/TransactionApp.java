package com.zaggle.xpns.transactions;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.zaggle.xpns.transactions.config.ApplicationProperties;
import com.zaggle.xpns.transactions.config.CRLFLogConverter;
import com.zaggle.xpns.transactions.constant.TransactionsConstants;

@EnableScheduling
@SpringBootApplication
@EnableConfigurationProperties({ ApplicationProperties.class })
public class TransactionApp {

	private static final Logger log = LoggerFactory.getLogger(TransactionApp.class);

	private final Environment env;

	public TransactionApp(Environment env) {
		this.env = env;
	}

	@PostConstruct
	public void initApplication() {
		Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());
		if (activeProfiles.contains(TransactionsConstants.SPRING_PROFILE_DEVELOPMENT)
				&& activeProfiles.contains(TransactionsConstants.SPRING_PROFILE_PRODUCTION)) {
			log.error("You have misconfigured your application! It should not run "
					+ "with both the 'dev' and 'prod' profiles at the same time.");
		}
		if (activeProfiles.contains(TransactionsConstants.SPRING_PROFILE_DEVELOPMENT)
				&& activeProfiles.contains(TransactionsConstants.SPRING_PROFILE_K8S)) {
			log.error("You have misconfigured your application! It should not "
					+ "run with both the 'dev' and 'k8' profiles at the same time.");
		}
	}

	/**
	 * Main method, used to run the application.
	 *
	 * @param args the command line arguments.
	 */

	public static ConfigurableApplicationContext ctx;

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(TransactionApp.class);
		Map<String, Object> dp = new HashMap<>();
		dp.put(TransactionsConstants.SPRING_PROFILE_DEFAULT, TransactionsConstants.SPRING_PROFILE_DEVELOPMENT);
		app.setDefaultProperties(dp);
		ctx = app.run(args);
		Environment env = ctx.getEnvironment();
		logApplicationStartup(env);
	}

//	@Scheduled(initialDelay = 1000 * 86400)
//	public void testShutdown() {
//		try {
//			ctx.close();
//		} catch (Exception e) {
//
//		}
//	}

	private static void logApplicationStartup(Environment env) {
		// String protocol =
		// Optional.ofNullable(env.getProperty("server.ssl.key-store")).map(key ->
		// "https").orElse("http");
		String protocol = "http";
		String serverPort = env.getProperty("server.port");
		String contextPath = Optional.ofNullable(env.getProperty("server.servlet.context-path"))
				.filter(StringUtils::isNotBlank).orElse("/");
		String hostAddress = "localhost";
		try {
			hostAddress = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			log.warn("The host name could not be determined, using `localhost` as fallback");
		}
		log.info(CRLFLogConverter.CRLF_SAFE_MARKER,
				"\n----------------------------------------------------------\n\t"
						+ "Application '{}' is running! Access URLs:\n\t" + "Local: \t\t{}://localhost:{}{}\n\t"
						+ "External: \t{}://{}:{}{}\n\t"
						+ "Profile(s): \t{}\n----------------------------------------------------------",
				env.getProperty("spring.application.name"), protocol, serverPort, contextPath, protocol, hostAddress,
				serverPort, contextPath,
				env.getActiveProfiles().length == 0 ? env.getDefaultProfiles() : env.getActiveProfiles());

		String configServerStatus = env.getProperty("configserver.status");
		configServerStatus = "UP"; // needs to pass from env
		if (configServerStatus == null) {
			configServerStatus = "Not found or not setup for this application";
		}
		log.info(CRLFLogConverter.CRLF_SAFE_MARKER,
				"\n----------------------------------------------------------\n\t"
						+ "Config Server: \t{}\n----------------------------------------------------------",
				configServerStatus);
	}
}
