package com.zaggle.xpns.transactions.service;

import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoDTO;
import java.util.Optional;

import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoRequestDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo}.
 */
public interface CardTransactionAddnInfoService {
    /**
     * Save a cardTransactionAddnInfo.
     *
     * @param cardTransactionAddnInfoReqDTO the entity to save.
     * @return the persisted entity.
     */
    CardTransactionAddnInfoDTO save(CardTransactionAddnInfoRequestDTO cardTransactionAddnInfoReqDTO);

    /**
     * Updates a cardTransactionAddnInfo.
     *
     * @param cardTransactionAddnInfoDTO the entity to update.
     * @return the persisted entity.
     */
    CardTransactionAddnInfoDTO update(CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO);

    /**
     * Partially updates a cardTransactionAddnInfo.
     *
     * @param cardTransactionAddnInfoDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<CardTransactionAddnInfoDTO> partialUpdate(CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO);

    /**
     * Get all the cardTransactionAddnInfos.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<CardTransactionAddnInfoDTO> findAll(Pageable pageable);

    /**
     * Get the "id" cardTransactionAddnInfo.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<CardTransactionAddnInfoDTO> findOne(Long id);

    /**
     * Delete the "id" cardTransactionAddnInfo.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
