package com.zaggle.xpns.transactions.config;

import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;

/**
 * 
 * 
 * This should be moved to Gateway service
 */
@Component
public class XpnsApiCustomizer implements OpenApiCustomiser, Ordered {
	
	@Autowired
	private CommanProperties properties;
	
    public static final int DEFAULT_ORDER = 0;

    private int order = DEFAULT_ORDER;
	
    public XpnsApiCustomizer(CommanProperties properties) {
        this.properties = properties;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    @Override
    public int getOrder() {
        return order;
    }

	@Override
	public void customise(OpenAPI openApi) {
		   Contact contact = new Contact()
		            .name("Yash")
		            .url("http://zaggle.in")
		            .email("testAdmin@zaggle.in");
		   
		   openApi.info(new Info()
		            .contact(contact)
		            .title("Card API Documentation")
		            .description("Card service API Documentation")
		            .version("1.0")
		            .termsOfService("http:\\termsurl")
		            .license(new License().name("Lincese Text").url("http://zaggle.in"))
		        );
		   
			
		   openApi.addServersItem(new Server().url("http://localhost:8186/").description("Cards API"));
	       
		    
		
	}

}
