package com.zaggle.xpns.transactions.service.dto;

import com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo;
import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;
import javax.validation.constraints.*;

/**
 * A DTO for the {@link com.zaggle.xpns.transactions.domain.CardTransactions} entity.
 */


 
@SuppressWarnings("common-java:DuplicatedBlocks")
public class CardTransactionsDTO implements Serializable {

    private Long id;

    private String entityId;



    /**
     * M2P’s transaction reference id
     */
    @NotNull
    @Schema(description = "M2P’s transaction reference id", required = true)

//    @Min(value = 1000)
    private String txnRefNo;

    private String cardRefNo;


    private String kitNo;


    private String mobileNo;


    private String cardType;


    private String merchantLocation;


    private String channel;


    private String txnCurrency;


    private String acquirerId;


    private String network;


    private String billingCurrency;


    private String accqInstitutionCode;


    private String corporate;


    /**
     * Transaction amount
     */
    @NotNull
    @Schema(description = "Transaction amount", required = true)
    private Double amount;

    /**
     * Available balance in card
     */
    @NotNull
    @Schema(description = "Available balance in card", required = true)
    private Double balance;

    /**
     * Transaction type
     */
    @NotNull
    @Schema(description = "Transaction type", required = true)
    private String transactionType;

    /**
     * Credit or Debit
     */
    @Schema(description = "Credit or Debit")
    private String crdr;

    /**
     * Transaction timestamp
     */
    @NotNull
    @Schema(description = "Transaction timestamp", required = true)
    private Long transactionDateTime;

    /**
     * Beneficiary’s name
     */
    @NotNull
    @Schema(description = "Beneficiary’s name", required = true)
    private String beneficiaryName;

    /**
     * Beneficiary’s type
     */
    @Schema(description = "Beneficiary’s type")
    private String beneficiaryType;

    /**
     * Beneficiary’s entity id
     */
    @Schema(description = "Beneficiary’s entity id")
    private String beneficiaryId;

    /**
     * Transaction description
     */
    @Schema(description = "Transaction description")
    private String description;

    /**
     * Transaction channel (Ex: Mobile, Web etc)
     */
    @Schema(description = "Transaction channel (Ex: Mobile, Web etc)")
    private String txnOrigin;

    /**
     * Beneficiary’s Name
     */
    @NotNull
    @Schema(description = "Beneficiary’s Name", required = true)
    private String otherPartyName;

    /**
     * Beneficiary’s Id
     */
    @Schema(description = "Beneficiary’s Id")
    private String otherPartyId;

    /**
     * Transaction status
     */
    @NotNull
    @Schema(description = "Transaction status", required = true)
    private String txnStatus;

    /**
     * Customer’s wallet name
     */
    @Schema(description = "Customer’s wallet name")
    private String customerWallet;

    /**
     * Beneficiary’s wallet name
     */
    @Schema(description = "Beneficiary’s wallet name")
    private String beneficiaryWallet;

    /**
     * Customer’s unique external Transaction Id
     */
    @NotNull
    @Schema(description = "Customer’s unique external Transaction Id", required = true)
    private String extTxnId;

    /**
     * Customer’s retrieval reference Number
     */
    @NotNull
    @Schema(description = "Customer’s retrieval reference Number", required = true)
    private String retrievalReferenceNo;

    /**
     * Customer’s authorization Code
     */
    @NotNull
    @Schema(description = "Customer’s authorization Code", required = true)
    private String authCode;

    /**
     * Customer’s bill reference Number
     */
    @NotNull
    @Schema(description = "Customer’s bill reference Number", required = true)
    private String billRefNo;

    /**
     * Customer’s Bank Transaction Id
     */
    @NotNull
    @Schema(description = "Customer’s Bank Transaction Id", required = true)
    private String bankTid;



    /**
     * Record created by user
     */
    @Size(min = 3, max = 20)
    @Schema(description = "Record created by user")
    private String createdBy;

    /**
     * Record created at time
     */
    @Schema(description = "Record created at time")
    private Instant createdDt;

    @Size(min = 3, max = 20)
    @Schema(description = "Record updated by user")
    private String updatedBy;

    /**
     * Record created at time
     */
    @Schema(description = "Record updated at time")
    private Instant updatedDt;
//    private Long cardTransactionsAddnInfo;

    public CardTransactionAddnInfo getJsonInfo() {
        return jsonInfo;
    }

    public void setJsonInfo(CardTransactionAddnInfo jsonInfo) {
        this.jsonInfo = jsonInfo;
    }

    private CardTransactionAddnInfo jsonInfo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getExtTxnId() {
        return extTxnId;
    }

    public String getTxnRefNo() {
        return txnRefNo;
    }

    public void setTxnRefNo(String txnRefNo) {
        this.txnRefNo = txnRefNo;
    }

    public String getCardRefNo() {
        return cardRefNo;
    }

    public void setCardRefNo(String cardRefNo) {
        this.cardRefNo = cardRefNo;
    }

    public String getKitNo() {
        return kitNo;
    }

    public void setKitNo(String kitNo) {
        this.kitNo = kitNo;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getMerchantLocation() {
        return merchantLocation;
    }

    public void setMerchantLocation(String merchantLocation) {
        this.merchantLocation = merchantLocation;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getTxnCurrency() {
        return txnCurrency;
    }

    public void setTxnCurrency(String txnCurrency) {
        this.txnCurrency = txnCurrency;
    }

    public String getAcquirerId() {
        return acquirerId;
    }

    public void setAcquirerId(String acquirerId) {
        this.acquirerId = acquirerId;
    }

    public String getNetwork() {
        return network;
    }

    public void setNetwork(String network) {
        this.network = network;
    }

    public String getBillingCurrency() {
        return billingCurrency;
    }

    public void setBillingCurrency(String billingCurrency) {
        this.billingCurrency = billingCurrency;
    }

    public String getAccqInstitutionCode() {
        return accqInstitutionCode;
    }

    public void setAccqInstitutionCode(String accqInstitutionCode) {
        this.accqInstitutionCode = accqInstitutionCode;
    }

    public String getCorporate() {
        return corporate;
    }

    public void setCorporate(String corporate) {
        this.corporate = corporate;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getCrdr() {
        return crdr;
    }

    public void setCrdr(String crdr) {
        this.crdr = crdr;
    }

    public Long getTransactionDateTime() {
        return transactionDateTime;
    }

    public void setTransactionDateTime(Long transactionDateTime) {
        this.transactionDateTime = transactionDateTime;
    }

    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    public String getBeneficiaryType() {
        return beneficiaryType;
    }

    public void setBeneficiaryType(String beneficiaryType) {
        this.beneficiaryType = beneficiaryType;
    }

    public String getBeneficiaryId() {
        return beneficiaryId;
    }

    public void setBeneficiaryId(String beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTxnOrigin() {
        return txnOrigin;
    }

    public void setTxnOrigin(String txnOrigin) {
        this.txnOrigin = txnOrigin;
    }

    public String getOtherPartyName() {
        return otherPartyName;
    }

    public void setOtherPartyName(String otherPartyName) {
        this.otherPartyName = otherPartyName;
    }

    public String getOtherPartyId() {
        return otherPartyId;
    }

    public void setOtherPartyId(String otherPartyId) {
        this.otherPartyId = otherPartyId;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public String getCustomerWallet() {
        return customerWallet;
    }

    public void setCustomerWallet(String customerWallet) {
        this.customerWallet = customerWallet;
    }

    public String getBeneficiaryWallet() {
        return beneficiaryWallet;
    }

    public void setBeneficiaryWallet(String beneficiaryWallet) {
        this.beneficiaryWallet = beneficiaryWallet;
    }

    public String getExternalTransactionId() {
        return extTxnId;
    }

    public void setExtTxnId(String extTxnId) {
        this.extTxnId = extTxnId;
    }

    public String getRetrievalReferenceNo() {
        return retrievalReferenceNo;
    }

    public void setRetrievalReferenceNo(String retrievalReferenceNo) {
        this.retrievalReferenceNo = retrievalReferenceNo;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getBillRefNo() {
        return billRefNo;
    }

    public void setBillRefNo(String billRefNo) {
        this.billRefNo = billRefNo;
    }

    public String getBankTid() {
        return bankTid;
    }

    public void setBankTid(String bankTid) {
        this.bankTid = bankTid;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Instant getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Instant createdDt) {
        this.createdDt = createdDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Instant getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Instant updatedDt) {
        this.updatedDt = updatedDt;
    }

//    public Long getCardTransactionsAddnInfo() {
//        return cardTransactionsAddnInfo;
//    }
//
//    public void setCardTransactionsAddnInfo(Long cardTransactionsAddnInfo) {
//        this.cardTransactionsAddnInfo = cardTransactionsAddnInfo;
//    }

    @Override
    public String toString() {
        return "CardTransactionsDTO{" +
                "id=" + id +
                "entityId=" + entityId + '\''+
                ", txnRefNo='" + txnRefNo + '\'' +
                ", cardRefNo='" + cardRefNo + '\'' +
                ", kitNo='" + kitNo + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                ", cardType='" + cardType + '\'' +
                ", merchantLocation='" + merchantLocation + '\'' +
                ", channel='" + channel + '\'' +
                ", txnCurrency='" + txnCurrency + '\'' +
                ", acquirerId='" + acquirerId + '\'' +
                ", network='" + network + '\'' +
                ", billingCurrency='" + billingCurrency + '\'' +
                ", accqInstitutionCode='" + accqInstitutionCode + '\'' +
                ", corporate='" + corporate + '\'' +
                ", amount=" + amount +
                ", balance=" + balance +
                ", transactionType='" + transactionType + '\'' +
                ", crdr='" + crdr + '\'' +
                ", transactionDateTime=" + transactionDateTime +
                ", beneficiaryName='" + beneficiaryName + '\'' +
                ", beneficiaryType='" + beneficiaryType + '\'' +
                ", beneficiaryId='" + beneficiaryId + '\'' +
                ", description='" + description + '\'' +
                ", txnOrigin='" + txnOrigin + '\'' +
                ", otherPartyName='" + otherPartyName + '\'' +
                ", otherPartyId='" + otherPartyId + '\'' +
                ", txnStatus='" + txnStatus + '\'' +
                ", customerWallet='" + customerWallet + '\'' +
                ", beneficiaryWallet='" + beneficiaryWallet + '\'' +
                ", externalTransactionId='" + extTxnId + '\'' +
                ", retrievalReferenceNo='" + retrievalReferenceNo + '\'' +
                ", authCode='" + authCode + '\'' +
                ", billRefNo='" + billRefNo + '\'' +
                ", bankTid='" + bankTid + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDt=" + createdDt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedDt=" + updatedDt +
//                ", cardTransactionsAddnInfo=" + cardTransactionsAddnInfo +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CardTransactionsDTO that = (CardTransactionsDTO) o;
        return Objects.equals(id, that.id) && Objects.equals(entityId, that.entityId) && Objects.equals(txnRefNo, that.txnRefNo) && Objects.equals(cardRefNo, that.cardRefNo) && Objects.equals(kitNo, that.kitNo) && Objects.equals(mobileNo, that.mobileNo) && Objects.equals(cardType, that.cardType) && Objects.equals(merchantLocation, that.merchantLocation) && Objects.equals(channel, that.channel) && Objects.equals(txnCurrency, that.txnCurrency) && Objects.equals(acquirerId, that.acquirerId) && Objects.equals(network, that.network) && Objects.equals(billingCurrency, that.billingCurrency) && Objects.equals(accqInstitutionCode, that.accqInstitutionCode) && Objects.equals(corporate, that.corporate) && Objects.equals(amount, that.amount) && Objects.equals(balance, that.balance) && Objects.equals(transactionType, that.transactionType) && Objects.equals(crdr, that.crdr) && Objects.equals(transactionDateTime, that.transactionDateTime) && Objects.equals(beneficiaryName, that.beneficiaryName) && Objects.equals(beneficiaryType, that.beneficiaryType) && Objects.equals(beneficiaryId, that.beneficiaryId) && Objects.equals(description, that.description) && Objects.equals(txnOrigin, that.txnOrigin) && Objects.equals(otherPartyName, that.otherPartyName) && Objects.equals(otherPartyId, that.otherPartyId) && Objects.equals(txnStatus, that.txnStatus) && Objects.equals(customerWallet, that.customerWallet) && Objects.equals(beneficiaryWallet, that.beneficiaryWallet) && Objects.equals(extTxnId, that.extTxnId) && Objects.equals(retrievalReferenceNo, that.retrievalReferenceNo) && Objects.equals(authCode, that.authCode) && Objects.equals(billRefNo, that.billRefNo) && Objects.equals(bankTid, that.bankTid) && Objects.equals(createdBy, that.createdBy) && Objects.equals(createdDt, that.createdDt) && Objects.equals(updatedBy, that.updatedBy) && Objects.equals(updatedDt, that.updatedDt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, entityId, txnRefNo, cardRefNo, kitNo, mobileNo, cardType, merchantLocation, channel, txnCurrency, acquirerId, network, billingCurrency, accqInstitutionCode, corporate, amount, balance, transactionType, crdr, transactionDateTime, beneficiaryName, beneficiaryType, beneficiaryId, description, txnOrigin, otherPartyName, otherPartyId, txnStatus, customerWallet, beneficiaryWallet, extTxnId, retrievalReferenceNo, authCode, billRefNo, bankTid, createdBy, createdDt, updatedBy, updatedDt);
    }
}
