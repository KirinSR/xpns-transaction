package com.zaggle.xpns.transactions.constant;

public interface TransactionsConstants {
	// Spring profiles for development, test and production
	
    /** Constant <code>SPRING_PROFILE_DEVELOPMENT="dev"</code> */
    String SPRING_PROFILE_STG = "stg";
    /** Constant <code>SPRING_PROFILE_DEVELOPMENT="dev"</code> */
    String SPRING_PROFILE_DEVELOPMENT = "dev";
    /** Constant <code>SPRING_PROFILE_TEST="test"</code> */
    String SPRING_PROFILE_TEST = "test";
    /** Constant <code>SPRING_PROFILE_PRODUCTION="prod"</code> */
    String SPRING_PROFILE_PRODUCTION = "prod";
    /** Spring profile used when deploying to Amazon ECS
        Constant <code>SPRING_PROFILE_AWS_ECS="aws-ecs"</code> */
    String SPRING_PROFILE_AWS_ECS = "aws-ecs";
    /** Spring profile used to enable OpenAPI doc generation
        Constant <code>SPRING_PROFILE_API_DOCS="api-docs"</code> */
    String SPRING_PROFILE_API_DOCS = "api-docs";
    /** Spring profile used to disable running liquibase
        Constant <code>SPRING_PROFILE_NO_LIQUIBASE="no-liquibase"</code> */
    String SPRING_PROFILE_NO_LIQUIBASE = "no-liquibase";
    /** Spring profile used when deploying to Kubernetes and OpenShift
        Constant <code>SPRING_PROFILE_K8S="k8s"</code> */
    String SPRING_PROFILE_K8S = "k8s";
    
    String SPRING_PROFILE_LOCAL = "local";
    
    String SPRING_PROFILE_DEFAULT = "spring.profiles.default";
    String ELKINDEX = "transaction_report";

    String ECOLLECTIONS_REPORT_INDEX = "ecollections_reports";
    String ECOLLECTION_REPORTS_MAIL_SUBJECT = "ECollection Report";
    String ECOLLECTION_DAILY_REPORT_TEMPLATE = "<p style=\" text-align: left; text-decoration: none !important; font-size: 15px !important; color: #333333; font-weight: 400; margin-top: 0px; margin-bottom: 0px; line-height: 32px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;    max-width: 90%; margin: auto;\">Hi Finance Team,</p>\n" +
            "                        <p style=\"width: 100%; height: 10px; margin: 0px;\"></p>\n" +
            "                        <p style=\" text-align: left; text-decoration: none !important; font-size: 15px !important; color: #333333; font-weight: 400; margin-top: 0px; margin-bottom: 0px; line-height: 32px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;    max-width: 90%; margin: auto;\">Today we have received following amount transfers from different companies till this time.</p>\n" +
            "                        <p style=\"width: 100%; height: 10px; margin: 0px;\"></p>\n" +
            "                        <p style=\" text-align: left; text-decoration: none !important; font-size: 15px !important; color: #333333; font-weight: 400; margin-top: 0px; margin-bottom: 0px; line-height: 32px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;    max-width: 90%; margin: auto;\">Please click on the button below to download the summary csv file for further processing.</p>\n" +
            "                        <p style=\"width: 100%; height: 10px; margin: 0px;\"></p>\n" +
            "                        <p style=\" text-align: left; text-decoration: none !important; font-size: 15px !important; color: #333333; font-weight: 400; margin-top: 0px; margin-bottom: 0px; line-height: 32px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;    max-width: 90%; margin: auto;\"><br/></p>\n" +
            "                        <p style=\"width: 100%; height: 20px; margin: 0px;\"></p>\n" +
            "                        <p style=\"width: 100%; margin: 0px; text-align: center;\"><a target=\"_blank\" href=\"https://admin-dev2.xpns.com/transactions/api/download/ecollectionReport\" style=\"font-weight: 400; display: inline-block; text-align: left; background-color: #116FFC; color: #fff !important; padding: 12px 54px; font-size: 16px; text-decoration: none;  line-height: 1.2; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif; margin-left: 15px; border-radius: 5px;\">Download eCollection Report</a></p>\n" +
            "                        <p style=\"width: 100%; height: 35px; margin: 0px;\"></p>\n" +
            "                        <p style=\" text-align: center; text-decoration: none !important; font-size: 14px !important; color: #666666; font-weight: 400; margin-top: 0px; margin-bottom: 0px; line-height: 32px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;    max-width: 90%; margin: auto;\">Any questions? Check out our Help Center or contact us at hello@xpns.com.</p>\n" +
            "                        <p style=\"width: 100%; height: 50px; margin: 0px;\"></p>\n" +
            "                        <p style=\" text-align: left; text-decoration: none !important; font-size: 14px !important; color: #666666; font-weight: 400; margin-top: 0px; margin-bottom: 0px; line-height: 32px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;    max-width: 90%; margin: auto;\">Always happy to help, </p>\n" +
            "                        <p style=\"width: 100%; height: 5px; margin: 0px;\"></p>\n" +
            "                        <p style=\" text-align: left; text-decoration: none !important; font-size: 14px !important; color: #666666; font-weight: 400; margin-top: 0px; margin-bottom: 0px; line-height: 16px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif;    max-width: 90%; margin: auto;\">Team XPNS. </p>\n" +
            "                        <p style=\"width: 100%; height: 50px; margin: 0px;\"></p>\n";
    String ECOLLECTION_DAILY_REPORT_TEMPLATEID = "ECollection Report";
    String[] ECOLLECTION_DAILY_REPORT_RECIEVER_MAILS = {"xpnsfinance@yopmail.com"};
}
