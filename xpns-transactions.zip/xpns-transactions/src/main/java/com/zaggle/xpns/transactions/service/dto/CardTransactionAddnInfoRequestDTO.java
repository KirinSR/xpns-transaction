package com.zaggle.xpns.transactions.service.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
//import org.h2.util.json.JSONObject;
import org.json.simple.JSONObject;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CardTransactionAddnInfoRequestDTO implements Serializable {
    private Long id;
    private JSONObject jsonInfo;
    private String createdBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public JSONObject getJsonInfo() {
        return jsonInfo;
    }

    public void setJsonInfo(JSONObject jsonInfo) {
        this.jsonInfo = jsonInfo;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public String toString() {
        return "CardTransactionAddnInfoRequestDTO{" +
                "id=" + id +
                ", jsonInfo='" + jsonInfo + '\'' +
                ", createdBy='" + createdBy + '\'' +
                '}';
    }
}
