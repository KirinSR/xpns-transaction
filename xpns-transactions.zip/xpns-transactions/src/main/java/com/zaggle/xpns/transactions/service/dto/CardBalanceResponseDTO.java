package com.zaggle.xpns.transactions.service.dto;

import java.util.Objects;

public class CardBalanceResponseDTO {
    private Double balance;
    private String updatedBy;

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CardBalanceResponseDTO that = (CardBalanceResponseDTO) o;
        return Objects.equals(balance, that.balance) && Objects.equals(updatedBy, that.updatedBy);
    }

    @Override
    public int hashCode() {
        return Objects.hash(balance, updatedBy);
    }

    @Override
    public String toString() {
        return "CardBalanceResponseDTO{" +
                "balance=" + balance +
                ", updatedBy='" + updatedBy + '\'' +
                '}';
    }
}
