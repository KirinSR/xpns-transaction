package com.zaggle.xpns.transactions.repository;

import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.domain.ECollectionTransactions;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EcollectionTransactionsRepository extends JpaRepository<ECollectionTransactions, Long>, JpaSpecificationExecutor<ECollectionTransactions> {

    List<ECollectionTransactions> findAllByCreditAccountNo(String creditAccountNo);

    List<ECollectionTransactions> findAllByOrgId(Pageable pageable, String orgId);

    List<ECollectionTransactions> findByOrgId(String orgId);
    @Query(value = "SELECT * FROM ecollection_transactions WHERE created_dt >= to_timestamp(:startDate, 'YYYY-MM-DD HH24:MI:SS') AND created_dt <=to_timestamp(:endDate, 'YYYY-MM-DD HH24:MI:SS')", nativeQuery = true)
    List<ECollectionTransactions> findAllInRange(@Param("startDate")String startDate, @Param("endDate") String endDate);
}
