package com.zaggle.xpns.transactions.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Objects;

@NoArgsConstructor
public class OrganisationDetailsDTO {

    private Long id;
    private String businessName;
    private String businessEmailAddress;
    private String phoneNumber;
    private String companyGSTNumber;
    private String businessPanCardNumber;
    private String corporateIdentificationNumber;
    private String status;
    private String tenantId;
    @JsonProperty(value = "isFirstTimeLogin")
    private boolean isFirstTimeLogin ;
    private String VirtualACNumber ;
    @JsonProperty("isCardService")
    private volatile boolean isCardService;
    private List<kybDocsAttachmentDto> kybDocsAttachments;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getBusinessEmailAddress() {
        return businessEmailAddress;
    }

    public void setBusinessEmailAddress(String businessEmailAddress) {
        this.businessEmailAddress = businessEmailAddress;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCompanyGSTNumber() {
        return companyGSTNumber;
    }

    public void setCompanyGSTNumber(String companyGSTNumber) {
        this.companyGSTNumber = companyGSTNumber;
    }

    public String getBusinessPanCardNumber() {
        return businessPanCardNumber;
    }

    public void setBusinessPanCardNumber(String businessPanCardNumber) {
        this.businessPanCardNumber = businessPanCardNumber;
    }

    public String getCorporateIdentificationNumber() {
        return corporateIdentificationNumber;
    }

    public void setCorporateIdentificationNumber(String corporateIdentificationNumber) {
        this.corporateIdentificationNumber = corporateIdentificationNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public boolean isFirstTimeLogin() {
        return isFirstTimeLogin;
    }

    public void setFirstTimeLogin(boolean firstTimeLogin) {
        isFirstTimeLogin = firstTimeLogin;
    }

    public String getVirtualACNumber() {
        return VirtualACNumber;
    }

    public void setVirtualACNumber(String virtualACNumber) {
        VirtualACNumber = virtualACNumber;
    }

    public boolean isCardService() {
        return isCardService;
    }

    public void setCardService(boolean cardService) {
        isCardService = cardService;
    }

    public List<kybDocsAttachmentDto> getKybDocsAttachments() {
        return kybDocsAttachments;
    }

    public void setKybDocsAttachments(List<kybDocsAttachmentDto> kybDocsAttachments) {
        this.kybDocsAttachments = kybDocsAttachments;
    }

    public OrganisationDetailsDTO(Long id, String businessName, String businessEmailAddress, String phoneNumber, String companyGSTNumber, String businessPanCardNumber, String corporateIdentificationNumber, String status, String tenantId, boolean isFirstTimeLogin, String virtualACNumber, boolean isCardService, List<kybDocsAttachmentDto> kybDocsAttachments) {
        this.id = id;
        this.businessName = businessName;
        this.businessEmailAddress = businessEmailAddress;
        this.phoneNumber = phoneNumber;
        this.companyGSTNumber = companyGSTNumber;
        this.businessPanCardNumber = businessPanCardNumber;
        this.corporateIdentificationNumber = corporateIdentificationNumber;
        this.status = status;
        this.tenantId = tenantId;
        this.isFirstTimeLogin = isFirstTimeLogin;
        VirtualACNumber = virtualACNumber;
        this.isCardService = isCardService;
        this.kybDocsAttachments = kybDocsAttachments;
    }

    @Override
    public String toString() {
        return "OrganisationDetailsDTO{" +
                "id=" + id +
                ", businessName='" + businessName + '\'' +
                ", businessEmailAddress='" + businessEmailAddress + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", companyGSTNumber='" + companyGSTNumber + '\'' +
                ", businessPanCardNumber='" + businessPanCardNumber + '\'' +
                ", corporateIdentificationNumber='" + corporateIdentificationNumber + '\'' +
                ", status='" + status + '\'' +
                ", tenantId='" + tenantId + '\'' +
                ", isFirstTimeLogin=" + isFirstTimeLogin +
                ", VirtualACNumber='" + VirtualACNumber + '\'' +
                ", isCardService=" + isCardService +
                ", kybDocsAttachments=" + kybDocsAttachments +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrganisationDetailsDTO that = (OrganisationDetailsDTO) o;
        return isFirstTimeLogin == that.isFirstTimeLogin && isCardService == that.isCardService && Objects.equals(id, that.id) && Objects.equals(businessName, that.businessName) && Objects.equals(businessEmailAddress, that.businessEmailAddress) && Objects.equals(phoneNumber, that.phoneNumber) && Objects.equals(companyGSTNumber, that.companyGSTNumber) && Objects.equals(businessPanCardNumber, that.businessPanCardNumber) && Objects.equals(corporateIdentificationNumber, that.corporateIdentificationNumber) && Objects.equals(status, that.status) && Objects.equals(tenantId, that.tenantId) && Objects.equals(VirtualACNumber, that.VirtualACNumber) && Objects.equals(kybDocsAttachments, that.kybDocsAttachments);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, businessName, businessEmailAddress, phoneNumber, companyGSTNumber, businessPanCardNumber, corporateIdentificationNumber, status, tenantId, isFirstTimeLogin, VirtualACNumber, isCardService, kybDocsAttachments);
    }
}
