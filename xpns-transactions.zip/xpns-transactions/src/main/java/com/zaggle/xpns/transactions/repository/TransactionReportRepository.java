package com.zaggle.xpns.transactions.repository;

import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.domain.TransactionReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface TransactionReportRepository extends JpaRepository<TransactionReport, Long>, JpaSpecificationExecutor<TransactionReport> {
}
