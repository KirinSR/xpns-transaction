package com.zaggle.xpns.transactions.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsDTO;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsRequestDTO;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.zaggle.xpns.transactions.service.dto.TransactionApiResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.zaggle.xpns.transactions.domain.CardTransactions}.
 */
public interface CardTransactionsService {
//    /**
//     * Save a cardTransactions.
//     *
//     * @param cardTransactionsDTO the entity to save.
//     * @return the persisted entity.
//     */
    CardTransactionsDTO save(CardTransactionsRequestDTO cardTransactionsReqDTO);

    /**
     * Updates a cardTransactions.
     *
     * @param cardTransactionsDTO the entity to update.
     * @return the persisted entity.
     */
    CardTransactionsDTO update(CardTransactionsDTO cardTransactionsDTO);

    /**
     * Partially updates a cardTransactions.
     *
     * @param cardTransactionsDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<CardTransactionsDTO> partialUpdate(CardTransactionsDTO cardTransactionsDTO) throws JsonProcessingException;

    /**
     * Get all the cardTransactions.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<CardTransactionsDTO> findAll(Pageable pageable);

    /**
     * Get the "id" cardTransactions.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<CardTransactionsDTO> findOne(Long id);

    /**
     * Delete the "id" cardTransactions.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);

    List<CardTransactions> findAllTransactionsByKitNo(Pageable pageable,String kitNo);

    List<CardTransactions> findAllTransactionsByKitNoInRange(String kitNo);
    TransactionApiResponse saveWebhook(Map<String, Object> requestBody) throws JsonProcessingException;

}
