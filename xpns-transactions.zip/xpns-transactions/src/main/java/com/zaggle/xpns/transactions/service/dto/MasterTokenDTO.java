package com.zaggle.xpns.transactions.service.dto;

import lombok.*;

import java.io.Serializable;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class MasterTokenDTO implements Serializable {
    private String client_id;
    private String username;
    private String password;
    private String grant_type;
    private String client_secret;
}
