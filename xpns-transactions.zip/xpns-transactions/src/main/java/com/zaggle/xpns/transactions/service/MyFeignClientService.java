package com.zaggle.xpns.transactions.service;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.zaggle.xpns.transactions.config.FeignConfiguration;

@FeignClient(name = "myFeignClientService", url = "base_url/api/v1", configuration = FeignConfiguration.class)
public interface MyFeignClientService {

	@PostMapping(value = "/path", consumes = "application/json")
	String somePostMethod(@RequestBody String body, @RequestHeader("headerMap") Map<String, Object> headerMap);



}
