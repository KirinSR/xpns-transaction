package com.zaggle.xpns.transactions.domain;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
//import org.h2.util.json.JSONObject;
import org.hibernate.annotations.TypeDef;
import org.json.simple.JSONObject;
import org.hibernate.annotations.Type;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import javax.persistence.*;
import javax.validation.constraints.*;

/**
 * A CardTransactionAddnInfo.
 */
@Entity
@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@Table(name = "card_transactions_addl_info")
@SuppressWarnings("common-java:DuplicatedBlocks")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardTransactionAddnInfo implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGeneratorCardTransactionAddnInfo")
    @SequenceGenerator(name = "sequenceGeneratorCardTransactionAddnInfo")
    @Column(name = "id")
    private Long id;

    /**
     * json string of transaction info
     */
//    @NotNull
    @Type(type = "jsonb")
    @Column(name = "json_info", columnDefinition = "json")
    private JSONObject jsonInfo;

    @CreatedDate
    @Column(name = "created_dt", updatable = false)
    private Instant createdDt = Instant.now();

    @CreatedBy
    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by", length = 50)
    private String updatedBy;

    @Column(name = "updated_dt")
    private Instant updatedDt = Instant.now();
}
