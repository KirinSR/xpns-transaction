package com.zaggle.xpns.transactions.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
//import org.h2.util.json.JSONObject;
import org.json.simple.JSONObject;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;
import javax.validation.constraints.*;

/**
 * A DTO for the {@link com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class CardTransactionAddnInfoDTO implements Serializable {

    private Long id;

    /**
     * json string of transaction info
     */
    @NotNull
    @Schema(description = "json string of transaction info", required = true)
    private JSONObject jsonInfo;

    /**
     * Record created by user
     */
    @Size(min = 3, max = 20)
    @Schema(description = "Record created by user")
    private String createdBy;

    /**
     * Record created at time
     */
    @Schema(description = "Record created at time")
    private Instant createdDt;

    /**
     * Record updated at time
     */
    @Schema(description = "Record updated at time")
    private Instant updatedDt;

    /**
     * Record updated by user
     * */

    @Size(min = 3, max = 20)
    @Schema(description = "Record updated by user")
    private String updatedBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public JSONObject getJsonInfo() {
        return jsonInfo;
    }

    public void setJsonInfo(JSONObject jsonInfo) {
        this.jsonInfo = jsonInfo;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Instant getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Instant createdDt) {
        this.createdDt = createdDt;
    }

    public Instant getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Instant updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CardTransactionAddnInfoDTO that = (CardTransactionAddnInfoDTO) o;
        return Objects.equals(id, that.id) && Objects.equals(jsonInfo, that.jsonInfo) && Objects.equals(createdBy, that.createdBy) && Objects.equals(createdDt, that.createdDt) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, jsonInfo, createdBy, createdDt);
    }

    @Override
    public String toString() {
        return "CardTransactionAddnInfoDTO{" +
                "id=" + id +
                ", jsonInfo='" + jsonInfo + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDt=" + createdDt +
              //  ", updatedDt=" + updatedDt +
               // ", updatedBy='" + updatedBy + '\'' +
                '}';
    }
}
