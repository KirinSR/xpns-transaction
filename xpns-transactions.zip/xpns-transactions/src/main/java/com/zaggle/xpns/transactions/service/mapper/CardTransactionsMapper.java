package com.zaggle.xpns.transactions.service.mapper;

import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsDTO;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsRequestDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity {@link CardTransactions} and its DTO {@link CardTransactionsDTO}.
 */
@Mapper(componentModel = "spring")
public interface CardTransactionsMapper extends EntityMapper<CardTransactionsDTO, CardTransactions> {

    CardTransactions toEntity(CardTransactionsRequestDTO cardTransactionsReqDTO);
}
