package com.zaggle.xpns.transactions.web.rest;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.zaggle.xpns.transactions.config.TimeTraker;
import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.zaggle.xpns.transactions.repository.CardTransactionAddnInfoRepository;
import com.zaggle.xpns.transactions.service.CardTransactionAddnInfoService;
import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoDTO;
import com.zaggle.xpns.transactions.util.PaginationUtil;
import com.zaggle.xpns.transactions.util.XpnsHeaderUtil;
import com.zaggle.xpns.transactions.util.XpnsResponseUtil;
import com.zaggle.xpns.transactions.web.rest.errors.BadRequestAlertException;
/**
 * REST controller for managing {@link com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo}.
 */
@RestController
@RequestMapping("/api")
public class CardTransactionAddnInfoResource {

    private final Logger log = LoggerFactory.getLogger(CardTransactionAddnInfoResource.class);

    private static final String ENTITY_NAME = "transactionsCardTransactionAddnInfo";

    @Value("${xpns.clientApp.name}")
    private String applicationName;

    private final CardTransactionAddnInfoService cardTransactionAddnInfoService;

    private final CardTransactionAddnInfoRepository cardTransactionAddnInfoRepository;

    public CardTransactionAddnInfoResource(
        CardTransactionAddnInfoService cardTransactionAddnInfoService,
        CardTransactionAddnInfoRepository cardTransactionAddnInfoRepository
    ) {
        this.cardTransactionAddnInfoService = cardTransactionAddnInfoService;
        this.cardTransactionAddnInfoRepository = cardTransactionAddnInfoRepository;
    }

//    /**
//     * {@code POST  /card-transaction-addn-infos} : Create a new cardTransactionAddnInfo.
//     *
//     * @param cardTransactionAddnInfoDTO the cardTransactionAddnInfoDTO to create.
//     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new cardTransactionAddnInfoDTO, or with status {@code 400 (Bad Request)} if the cardTransactionAddnInfo has already an ID.
//     * @throws URISyntaxException if the Location URI syntax is incorrect.
//     */
    @PostMapping("/card-transaction-addn-infos")
    @TimeTraker
    public ResponseEntity<CardTransactionAddnInfoDTO> createCardTransactionAddnInfo(
            @Valid @RequestBody CardTransactionAddnInfoRequestDTO cardTransactionAddnInfoReqDTO
    ) throws URISyntaxException {
        log.debug("REST request to save CardTransactionAddnInfo : {}", cardTransactionAddnInfoReqDTO);
        if (cardTransactionAddnInfoReqDTO.getId() != null) {
            throw new BadRequestAlertException("A new cardTransactionAddnInfo cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CardTransactionAddnInfoDTO result = cardTransactionAddnInfoService.save(cardTransactionAddnInfoReqDTO);
        return ResponseEntity
            .created(new URI("/api/card-transaction-addn-infos/" + result.getId()))
            .headers(XpnsHeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /card-transaction-addn-infos/:id} : Updates an existing cardTransactionAddnInfo.
     *
     * @param id                         the id of the cardTransactionAddnInfoDTO to save.
     * @param cardTransactionAddnInfoDTO the cardTransactionAddnInfoDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated cardTransactionAddnInfoDTO,
     * or with status {@code 400 (Bad Request)} if the cardTransactionAddnInfoDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the cardTransactionAddnInfoDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/card-transaction-addn-infos/{id}")
    @TimeTraker
    public ResponseEntity<Optional<CardTransactionAddnInfoDTO>> updateCardTransactionAddnInfo(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO
    ) throws URISyntaxException {
        log.debug("REST request to update CardTransactionAddnInfo : {}, {}", id, cardTransactionAddnInfoDTO);
        if (cardTransactionAddnInfoDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, cardTransactionAddnInfoDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!cardTransactionAddnInfoRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        CardTransactionAddnInfoDTO result = cardTransactionAddnInfoService.update(cardTransactionAddnInfoDTO);
        return ResponseEntity
                .ok()
                .headers(XpnsHeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, cardTransactionAddnInfoDTO.getId().toString()))
                .body(Optional.ofNullable(result));


    }

    /**
     * {@code PATCH  /card-transaction-addn-infos/:id} : Partial updates given fields of an existing cardTransactionAddnInfo, field will ignore if it is null
     *
     * @param id the id of the cardTransactionAddnInfoDTO to save.
     * @param cardTransactionAddnInfoDTO the cardTransactionAddnInfoDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated cardTransactionAddnInfoDTO,
     * or with status {@code 400 (Bad Request)} if the cardTransactionAddnInfoDTO is not valid,
     * or with status {@code 404 (Not Found)} if the cardTransactionAddnInfoDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the cardTransactionAddnInfoDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/card-transaction-addn-infos/{id}", consumes = { "application/json", "application/merge-patch+json" })
    @TimeTraker
    public ResponseEntity<CardTransactionAddnInfoDTO> partialUpdateCardTransactionAddnInfo(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO
    ) throws URISyntaxException {
        log.info("REST request to partial update CardTransactionAddnInfo partially : {}, {}", id, cardTransactionAddnInfoDTO);
        if (cardTransactionAddnInfoDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, cardTransactionAddnInfoDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!cardTransactionAddnInfoRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<CardTransactionAddnInfoDTO> result = cardTransactionAddnInfoService.partialUpdate(cardTransactionAddnInfoDTO);

        return XpnsResponseUtil.wrapOrNotFound(
            result,
            XpnsHeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, cardTransactionAddnInfoDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /card-transaction-addn-infos} : get all the cardTransactionAddnInfos.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of cardTransactionAddnInfos in body.
     */
    @GetMapping("/card-transaction-addn-infos")
    @TimeTraker
    public ResponseEntity<List<CardTransactionAddnInfoDTO>> getAllCardTransactionAddnInfos(
        @org.springdoc.api.annotations.ParameterObject Pageable pageable
    ) {
        log.info("REST request to get a page of CardTransactionAddnInfos");
        Page<CardTransactionAddnInfoDTO> page = cardTransactionAddnInfoService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.getPageHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /card-transaction-addn-infos/:id} : get the "id" cardTransactionAddnInfo.
     *
     * @param id the id of the cardTransactionAddnInfoDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the cardTransactionAddnInfoDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/card-transaction-addn-infos/{id}")
    @TimeTraker
    public ResponseEntity<CardTransactionAddnInfoDTO> getCardTransactionAddnInfo(@PathVariable Long id) {
        log.info("REST request to get CardTransactionAddnInfo : {}", id);
        Optional<CardTransactionAddnInfoDTO> cardTransactionAddnInfoDTO = cardTransactionAddnInfoService.findOne(id);
        return XpnsResponseUtil.wrapOrNotFound(cardTransactionAddnInfoDTO);
    }

    /**
     * {@code DELETE  /card-transaction-addn-infos/:id} : delete the "id" cardTransactionAddnInfo.
     *
     * @param id the id of the cardTransactionAddnInfoDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/card-transaction-addn-infos/{id}")
    @TimeTraker
    public ResponseEntity<Void> deleteCardTransactionAddnInfo(@PathVariable Long id) {
        log.info("REST request to delete CardTransactionAddnInfo : {}", id);
        cardTransactionAddnInfoService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(XpnsHeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
