package com.zaggle.xpns.transactions.domain;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Base abstract class for entities which will hold definitions for created, last modified, created by,
 * last modified by attributes.
 */
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(value = { "createdBy", "createdDt", "updatedBy", "updatedDt"}, allowGetters = true)
public abstract class AbstractAuditingEntity<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    public abstract T getId();

    @CreatedBy
    @Column(name = "created_by")
    private String createdBy;

    @CreatedDate
    @Column(name = "created_dt", updatable = false)
    private Instant createdDt = Instant.now();

	@LastModifiedBy
	@Column(name = "updated_by", length = 50)
	private String updatedBy;

    @LastModifiedDate
    @Column(name = "updated_dt")
    private Instant updatedDt = Instant.now();

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Instant getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Instant createdDt) {
        this.createdDt = createdDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Instant getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Instant updatedDt) {
        this.updatedDt = updatedDt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AbstractAuditingEntity<?> that = (AbstractAuditingEntity<?>) o;
        return Objects.equals(createdBy, that.createdBy) && Objects.equals(createdDt, that.createdDt) && Objects.equals(updatedDt, that.updatedDt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(createdBy, createdDt, updatedDt);
    }

    @Override
    public String toString() {
        return "AbstractAuditingEntity{" +
                "createdBy='" + createdBy + '\'' +
                ", createdDt=" + createdDt +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedDt=" + updatedDt +
                '}';
    }
}
