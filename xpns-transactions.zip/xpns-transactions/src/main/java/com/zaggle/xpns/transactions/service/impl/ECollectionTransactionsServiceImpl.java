package com.zaggle.xpns.transactions.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.domain.ECollectionTransactions;
import com.zaggle.xpns.transactions.repository.EcollectionTransactionsRepository;
import com.zaggle.xpns.transactions.service.ECollectionTransactionsService;
import com.zaggle.xpns.transactions.service.dto.*;
import com.zaggle.xpns.transactions.service.mapper.ECollectionTransactionsMapper;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.*;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class ECollectionTransactionsServiceImpl implements ECollectionTransactionsService {

    private final Logger log = LoggerFactory.getLogger(CardTransactionsServiceImpl.class);

    private final EcollectionTransactionsRepository ecollectionTransactionsRepository;
    private final ECollectionTransactionsMapper eCollectionTransactionsMapper;

    @Value("${internal-apis.master-token-url}")
    private String masterTokenUrl;

    @Value("${internal-apis.van-by-org-url}")
    private String getVanByOrgUrl;

    @Value("${internal-apis.update-pool-account-balance-url}")
    private String updatePoolAccountBalanceUrl;

    @Value("${master-token-credentials.client_id}")
    private String client_id;

    @Value("${master-token-credentials.grant_type}")
    private String grant_type;

    @Value("${master-token-credentials.username}")
    private String username;

    @Value("${master-token-credentials.password}")
    private String password;

    @Value("${master-token-credentials.client_secret}")
    private String client_secret;



    public ECollectionTransactionsServiceImpl(EcollectionTransactionsRepository ecollectionTransactionsRepository, ECollectionTransactionsMapper eCollectionTransactionsMapper) {
        this.ecollectionTransactionsRepository = ecollectionTransactionsRepository;
        this.eCollectionTransactionsMapper = eCollectionTransactionsMapper;
    }


    @Override
    public ECollectionTransactions save(ECollectionTransactionsDTO eCollectionTransactionsDTO) throws JsonProcessingException {
        log.info("Request to save EcollectionTransactions : {}", eCollectionTransactionsDTO);

        ECollectionTransactions eCollectionTransaction = eCollectionTransactionsMapper.toEntity(eCollectionTransactionsDTO);

        BeanUtils.copyProperties(eCollectionTransactionsDTO, eCollectionTransaction);

        Instant instant = Instant.now();
        DateTimeFormatter formatter = DateTimeFormatter.ISO_INSTANT;
        String formattedInstant = formatter.format(instant);
        JSONObject jsonObject = new JSONObject();
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        Object obj = new Object();
        ObjectMapper objectMapper = new ObjectMapper();
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders masterHeaders = new HttpHeaders();

//        MASTER TOKEN LOGIN

        List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();
        messageConverters.add(new FormHttpMessageConverter());
        messageConverters.add(new MappingJackson2HttpMessageConverter());
        restTemplate.setMessageConverters(messageConverters);

        MasterTokenDTO masterTokenDto = new MasterTokenDTO();
        masterTokenDto.setClient_id(client_id);
        masterTokenDto.setGrant_type(grant_type);
        masterTokenDto.setUsername(username);
        masterTokenDto.setPassword(password);
        masterTokenDto.setClient_secret(client_secret);

        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("client_id", masterTokenDto.getClient_id());
        formData.add("grant_type", masterTokenDto.getGrant_type());
        formData.add("username", masterTokenDto.getUsername());
        formData.add("password", masterTokenDto.getPassword());
        formData.add("client_secret", masterTokenDto.getClient_secret());

        masterHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<MultiValueMap<String, String>> masterEntity = new HttpEntity<>(formData, masterHeaders);
        ResponseEntity<Object> masterResponseEntity = restTemplate.exchange( masterTokenUrl, HttpMethod.POST, masterEntity, Object.class);
        Map<String, Object> result = (Map<String, Object>) masterResponseEntity.getBody();
        String masterToken = (String) result.get("access_token");

        HttpHeaders headers = new HttpHeaders();
        OrganisationDetailsDTO orgDetailsList = new OrganisationDetailsDTO();
        headers.setBearerAuth(masterToken);
        HttpEntity<String> entity = new HttpEntity<>(headers);

        ResponseEntity<OrganisationDetailsDTO[]> responseEntityNew = restTemplate.exchange( getVanByOrgUrl+eCollectionTransaction.getCreditAccountNo(), HttpMethod.GET, entity, OrganisationDetailsDTO[].class);

        OrganisationDetailsDTO[] orgDetails = responseEntityNew.getBody();
        String orgId = null;
        for (OrganisationDetailsDTO organisationDetailsDTO: orgDetails){
                orgId = organisationDetailsDTO.getTenantId();
        }

        String jsonString = mapper.writeValueAsString(eCollectionTransaction);
        eCollectionTransaction.setJson_info(eCollectionTransactionsDTO);
        eCollectionTransaction.setCreatedDt(Instant.now());
        eCollectionTransaction.setCreatedBy("ZIG");


        headers.setBearerAuth(masterToken);
        CreditBalanceDTO creditBalanceDto = new CreditBalanceDTO();
        creditBalanceDto.setOrgId(orgId);
        creditBalanceDto.setDescreption("E-collection balance update");

        creditBalanceDto.setType("CREDIT");
        creditBalanceDto.setAmount(eCollectionTransaction.getAmount());
        HttpEntity<CreditBalanceDTO> result1 = new HttpEntity<>(creditBalanceDto, headers);
        ResponseEntity<Object> responseEntity = restTemplate.exchange(updatePoolAccountBalanceUrl, HttpMethod.POST, result1, Object.class);
        log.info("Update Pool Account balance: ", responseEntity.getBody());
        Map<String, Object> resultUpdateBalance = (Map<String, Object>) responseEntity.getBody();
        eCollectionTransaction.setBalance(Double.parseDouble(resultUpdateBalance.get("balance").toString()));
        eCollectionTransaction.setOrgId(orgId);


        eCollectionTransaction = ecollectionTransactionsRepository.save(eCollectionTransaction);

        return eCollectionTransactionsMapper.toDto(eCollectionTransaction);
    }

    @Override
    public void delete(Long id) {

    }

    @Override
    public List<ECollectionTransactions> getAll(Pageable pageable) {
        return null;
    }

    @Override
    public List<ECollectionTransactions> getAllByOrgId(Pageable pageRequest, String orgId) {
        log.info("Request to get all EcollectionTransactions : {}", orgId);
        List<ECollectionTransactions> transactions = ecollectionTransactionsRepository.findAllByOrgId(pageRequest, orgId);
        return transactions;
    }

    @Override
    public OrgAccountDetailsDTO getOrgAccountDetails(String orgId) {
        log.info("Request to get organisation account details : {}", orgId);
        List<ECollectionTransactions> transactions = ecollectionTransactionsRepository.findByOrgId(orgId);
        ECollectionTransactions transaction = transactions.get(0);
        OrgAccountDetailsDTO orgAccountDetailsDTO = new OrgAccountDetailsDTO();
        orgAccountDetailsDTO.setAccountName(transaction.getRemitterName());
        orgAccountDetailsDTO.setAccountNumber(transaction.getCreditAccountNo());
        orgAccountDetailsDTO.setBranch(transaction.getRemitterBranch());
        orgAccountDetailsDTO.setIFSCCode(transaction.getRemitterIFSC());
        orgAccountDetailsDTO.setAddress(transaction.getReserve1());
        orgAccountDetailsDTO.setBankName(transaction.getRemitterBank());
        orgAccountDetailsDTO.setAccountType("CURRENT");

;        return orgAccountDetailsDTO;
    }

    @Override
    public byte[] generateEcollectionReport() {
        LocalDate yesterday = LocalDate.now().minusDays(1);
        LocalDate today = LocalDate.now();
        LocalDateTime yesterdayStart = yesterday.atStartOfDay();
        LocalDateTime todayEnd = today.atStartOfDay();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd 17:15:00");
        List<ECollectionTransactions> eCollectionTransactionsList = ecollectionTransactionsRepository.findAllInRange(yesterdayStart.format(formatter), todayEnd.format(formatter));
        System.out.println("Ecollections report: " + eCollectionTransactionsList.stream().map(ECollectionTransactions::getId).map(Object::toString).collect(Collectors.joining(", ")));
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=Ecollection_Report"+LocalDateTime.now()+".csv");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        // Define the separator for the CSV file
        StringBuilder csvFileBuilder = new StringBuilder();
        csvFileBuilder.append("\"id\",\"orgId\",\"creditAccountNo\",\"ChallanNo\",\"ChallanCode\",\"Amount\",\"PayMethod\",\"RequestId\",\"ClientName\",\"ClientAccountNo\",\"Balance\",\"RemitterAccountNo\",\"RemitterName\",\"RemitterIFSC\",\"RemitterBank\",\"RemitterBranch\",\"RemitterUTR\",\"Reserve1\",\"Reserve2\",\"Reserve3\",\"Reserve4\",\"CreditTime\",\"InwardRefNum\"");
        csvFileBuilder.append("\n");
        for (ECollectionTransactions ecollectionTransaction : eCollectionTransactionsList) {
            csvFileBuilder.append(ecollectionTransaction.getId())
                    .append(",")
                    .append(ecollectionTransaction.getOrgId())
                    .append(",")
                    .append(ecollectionTransaction.getCreditAccountNo())
                    .append(",")
                    .append(ecollectionTransaction.getChallanNo())
                    .append(",")
                    .append(ecollectionTransaction.getChallanCode())
                    .append(",")
                    .append(ecollectionTransaction.getAmount())
                    .append(",")
                    .append(ecollectionTransaction.getPayMethod())
                    .append(",")
                    .append(ecollectionTransaction.getRequestId())
                    .append(",")
                    .append(ecollectionTransaction.getClientName())
                    .append(",")
                    .append(ecollectionTransaction.getClientAccountNo())
                    .append(",")
                    .append(ecollectionTransaction.getBalance())
                    .append(",")
                    .append(ecollectionTransaction.getRemitterAccountNo())
                    .append(",")
                    .append(ecollectionTransaction.getRemitterName())
                    .append(",")
                    .append(ecollectionTransaction.getRemitterIFSC())
                    .append(",")
                    .append(ecollectionTransaction.getRemitterBank())
                    .append(",")
                    .append(ecollectionTransaction.getRemitterBranch())
                    .append(",")
                    .append(ecollectionTransaction.getRemitterUTR())
                    .append(",")
                    .append(ecollectionTransaction.getReserve1())
                    .append(",")
                    .append(ecollectionTransaction.getReserve2())
                    .append(",")
                    .append(ecollectionTransaction.getReserve3())
                    .append(",")
                    .append(ecollectionTransaction.getReserve4())
                    .append(",")
                    .append(ecollectionTransaction.getCreditTime())
                    .append(",")
                    .append(ecollectionTransaction.getInwardRefNum())
                    .append("\n");
        }


        byte[] in= csvFileBuilder.toString().getBytes();
//        return new ByteArrayInputStream(csvFileBuilder.toString().getBytes());
        return in;
//        return new byte[0];
    }
}
