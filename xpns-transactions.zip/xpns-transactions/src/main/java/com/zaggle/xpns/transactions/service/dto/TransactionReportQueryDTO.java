package com.zaggle.xpns.transactions.service.dto;

import lombok.*;

import java.io.Serializable;


public class TransactionReportQueryDTO {
    String cardRef;
    Double total_amount;

    public String getCardRef() {
        return cardRef;
    }

    public void setCardRef(String cardRef) {
        this.cardRef = cardRef;
    }

    public Double getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(Double total_amount) {
        this.total_amount = total_amount;
    }

    public TransactionReportQueryDTO(String cardRef, Double total_amount) {
        this.cardRef = cardRef;
        this.total_amount = total_amount;
    }
}
