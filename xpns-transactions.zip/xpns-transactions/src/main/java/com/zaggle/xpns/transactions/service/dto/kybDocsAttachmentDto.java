package com.zaggle.xpns.transactions.service.dto;

import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.Objects;


@NoArgsConstructor
public class kybDocsAttachmentDto {
    private String id;
    private String tenantId;
    private String orgKYBStatus;
    private String attachmentStatus;
    private String createdBy;
    private Instant createdDate;
    private String updatedBy;
    private Instant updatedDate ;
    private String filePath;
    private Instant uploadDate;
    private String uploadStatus;
    private String approvedBy;
    private String approvedStatus;
    private Instant approvedDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getOrgKYBStatus() {
        return orgKYBStatus;
    }

    public void setOrgKYBStatus(String orgKYBStatus) {
        this.orgKYBStatus = orgKYBStatus;
    }

    public String getAttachmentStatus() {
        return attachmentStatus;
    }

    public void setAttachmentStatus(String attachmentStatus) {
        this.attachmentStatus = attachmentStatus;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Instant getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Instant getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Instant updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public Instant getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(Instant uploadDate) {
        this.uploadDate = uploadDate;
    }

    public String getUploadStatus() {
        return uploadStatus;
    }

    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }

    public String getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(String approvedBy) {
        this.approvedBy = approvedBy;
    }

    public String getApprovedStatus() {
        return approvedStatus;
    }

    public void setApprovedStatus(String approvedStatus) {
        this.approvedStatus = approvedStatus;
    }

    public Instant getApprovedDate() {
        return approvedDate;
    }

    public void setApprovedDate(Instant approvedDate) {
        this.approvedDate = approvedDate;
    }

    public kybDocsAttachmentDto(String id, String tenantId, String orgKYBStatus, String attachmentStatus, String createdBy, Instant createdDate, String updatedBy, Instant updatedDate, String filePath, Instant uploadDate, String uploadStatus, String approvedBy, String approvedStatus, Instant approvedDate) {
        this.id = id;
        this.tenantId = tenantId;
        this.orgKYBStatus = orgKYBStatus;
        this.attachmentStatus = attachmentStatus;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.updatedBy = updatedBy;
        this.updatedDate = updatedDate;
        this.filePath = filePath;
        this.uploadDate = uploadDate;
        this.uploadStatus = uploadStatus;
        this.approvedBy = approvedBy;
        this.approvedStatus = approvedStatus;
        this.approvedDate = approvedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        kybDocsAttachmentDto that = (kybDocsAttachmentDto) o;
        return Objects.equals(id, that.id) && Objects.equals(tenantId, that.tenantId) && Objects.equals(orgKYBStatus, that.orgKYBStatus) && Objects.equals(attachmentStatus, that.attachmentStatus) && Objects.equals(createdBy, that.createdBy) && Objects.equals(createdDate, that.createdDate) && Objects.equals(updatedBy, that.updatedBy) && Objects.equals(updatedDate, that.updatedDate) && Objects.equals(filePath, that.filePath) && Objects.equals(uploadDate, that.uploadDate) && Objects.equals(uploadStatus, that.uploadStatus) && Objects.equals(approvedBy, that.approvedBy) && Objects.equals(approvedStatus, that.approvedStatus) && Objects.equals(approvedDate, that.approvedDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, tenantId, orgKYBStatus, attachmentStatus, createdBy, createdDate, updatedBy, updatedDate, filePath, uploadDate, uploadStatus, approvedBy, approvedStatus, approvedDate);
    }

    @Override
    public String toString() {
        return "kybDocsAttachmentDto{" +
                "id='" + id + '\'' +
                ", tenantId='" + tenantId + '\'' +
                ", orgKYBStatus='" + orgKYBStatus + '\'' +
                ", attachmentStatus='" + attachmentStatus + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedDate=" + updatedDate +
                ", filePath='" + filePath + '\'' +
                ", uploadDate=" + uploadDate +
                ", uploadStatus='" + uploadStatus + '\'' +
                ", approvedBy='" + approvedBy + '\'' +
                ", approvedStatus='" + approvedStatus + '\'' +
                ", approvedDate=" + approvedDate +
                '}';
    }
}
