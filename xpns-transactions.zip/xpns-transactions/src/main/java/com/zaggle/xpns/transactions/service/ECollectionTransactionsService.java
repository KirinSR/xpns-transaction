package com.zaggle.xpns.transactions.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.xpns.transactions.domain.ECollectionTransactions;
import com.zaggle.xpns.transactions.service.dto.ECollectionTransactionsDTO;
import com.zaggle.xpns.transactions.service.dto.OrgAccountDetailsDTO;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ECollectionTransactionsService {
    ECollectionTransactions save(ECollectionTransactionsDTO eCollectionTransactionsDTO) throws JsonProcessingException;

//    Optional<ECollectionTransactions> update(ECollectionTransactionsDTO eCollectionTransactionsDTO);

    void delete(Long id);

    List<ECollectionTransactions> getAll(Pageable pageable);

    List<ECollectionTransactions> getAllByOrgId(Pageable pageRequest, String ecollectionId);

    OrgAccountDetailsDTO getOrgAccountDetails(String tenantId);

    byte[] generateEcollectionReport();
}
