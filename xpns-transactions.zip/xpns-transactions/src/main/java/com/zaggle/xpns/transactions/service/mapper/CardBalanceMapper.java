package com.zaggle.xpns.transactions.service.mapper;

import com.zaggle.xpns.transactions.domain.CardBalance;
import com.zaggle.xpns.transactions.service.dto.CardBalanceDTO;
import com.zaggle.xpns.transactions.service.dto.CardBalanceResponseDTO;
import org.mapstruct.Mapper;

import java.util.Optional;

@Mapper(componentModel = "spring")
public interface CardBalanceMapper extends EntityMapper<CardBalanceDTO, CardBalance>{
//    CardBalanceResponseDTO toEntity(CardBalanceDTO cardBalancedto);

//    <U> Optional<CardBalanceResponseDTO> toEntity(Optional<U> u);
}
