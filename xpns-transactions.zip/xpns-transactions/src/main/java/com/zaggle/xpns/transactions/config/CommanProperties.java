package com.zaggle.xpns.transactions.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.web.cors.CorsConfiguration;

@ConfigurationProperties(prefix = "transactions", ignoreUnknownFields = false)
public class CommanProperties {

	private final ClientApp clientApp = new ClientApp();

	private final CorsConfiguration corsConf = new CorsConfiguration();

	private final Zig zig = new Zig();

	private final Logs logs = new Logs();

	private final Mail mail = new Mail();

	public ClientApp getClientApp() {
		return clientApp;
	}

	public Logs getLogs() {
		return logs;
	}

	public CorsConfiguration getCorsConf() {
		return corsConf;
	}

	public Zig getZig() {
		return zig;
	}

	public Mail getMail() {
		return mail;
	}

	static class ClientApp {
		private String name;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

	}

	static class Logs {
		private boolean enanled = false;
		private boolean useJsonFormat = false;
		private final Logstash logstash = new Logstash();

		public boolean isEnanled() {
			return enanled;
		}

		public void setEnanled(boolean enanled) {
			this.enanled = enanled;
		}

		public boolean isUseJsonFormat() {
			return useJsonFormat;
		}

		public void setUseJsonFormat(boolean useJsonFormat) {
			this.useJsonFormat = useJsonFormat;
		}

		public Logstash getLogstash() {
			return logstash;
		}

	}

	public static class Zig {

		private String xClientAppId;
		private String xClientId;
		private String xClientSignature;
		private String clientRefId;
		private String syncToken;

		public String getxClientAppId() {
			return xClientAppId;
		}

		public void setxClientAppId(String xClientAppId) {
			this.xClientAppId = xClientAppId;
		}

		public String getxClientId() {
			return xClientId;
		}

		public void setxClientId(String xClientId) {
			this.xClientId = xClientId;
		}

		public String getxClientSignature() {
			return xClientSignature;
		}

		public void setxClientSignature(String xClientSignature) {
			this.xClientSignature = xClientSignature;
		}

		public String getClientRefId() {
			return clientRefId;
		}

		public void setClientRefId(String clientRefId) {
			this.clientRefId = clientRefId;
		}

		public String getSyncToken() {
			return syncToken;
		}

		public void setSyncToken(String syncToken) {
			this.syncToken = syncToken;
		}

	}

	public static class Logstash {

		private boolean enabled = false;

		private String host = "localhost";

		private int port = 50000;

		private int ringBufferSize = 512;

		public boolean isEnabled() {
			return enabled;
		}

		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}

		public String getHost() {
			return host;
		}

		public void setHost(String host) {
			this.host = host;
		}

		public int getPort() {
			return port;
		}

		public void setPort(int port) {
			this.port = port;
		}

		@Deprecated
		public int getQueueSize() {
			return getRingBufferSize();
		}

		@Deprecated
		public void setQueueSize(int queueSize) {
			setRingBufferSize(queueSize);
		}

		public int getRingBufferSize() {
			return ringBufferSize;
		}

		public void setRingBufferSize(int ringBufferSize) {
			this.ringBufferSize = ringBufferSize;
		}
	}

	static class AuditEvents {
		private int retentionPeriod = 30;

		public int getRetentionPeriod() {
			return retentionPeriod;
		}

		public void setRetentionPeriod(int retentionPeriod) {
			this.retentionPeriod = retentionPeriod;
		}
	}

	public static class Mail {

		private boolean enabled = Boolean.FALSE;

		private String from = "yash@xyz.com";

		private String baseUrl = "";

		public boolean isEnabled() {
			return enabled;
		}

		public void setEnabled(boolean enabled) {
			this.enabled = enabled;
		}

		public String getFrom() {
			return from;
		}

		public void setFrom(String from) {
			this.from = from;
		}

		public String getBaseUrl() {
			return baseUrl;
		}

		public void setBaseUrl(String baseUrl) {
			this.baseUrl = baseUrl;
		}
	}

}
