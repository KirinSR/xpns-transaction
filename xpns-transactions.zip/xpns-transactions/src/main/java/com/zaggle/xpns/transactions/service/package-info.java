/**
 * Service layer beans.
 */
package com.zaggle.xpns.transactions.service;
