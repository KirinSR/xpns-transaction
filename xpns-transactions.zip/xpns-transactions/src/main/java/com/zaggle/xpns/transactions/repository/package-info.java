/**
 * Spring Data JPA repositories.
 */
package com.zaggle.xpns.transactions.repository;
