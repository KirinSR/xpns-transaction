package com.zaggle.xpns.transactions.web.rest;

import com.zaggle.xpns.transactions.config.TimeTraker;
import com.zaggle.xpns.transactions.repository.CardBalanceRepository;
import com.zaggle.xpns.transactions.service.CardBalanceService;
import com.zaggle.xpns.transactions.service.dto.CardBalanceDTO;
import com.zaggle.xpns.transactions.service.dto.CardBalanceResponseDTO;
import com.zaggle.xpns.transactions.util.XpnsHeaderUtil;
import com.zaggle.xpns.transactions.util.XpnsResponseUtil;
import com.zaggle.xpns.transactions.web.rest.errors.BadRequestAlertException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;


@RestController
@RequestMapping("/api")
public class CardBalanceResource {
    private final Logger log = LoggerFactory.getLogger(CardTransactionsResource.class);

    private static final String ENTITY_NAME = "transactionsCardBalance";

    @Value("${xpns.clientApp.name}")
    private String applicationName;

    private final CardBalanceService cardBalanceService;

    private final CardBalanceRepository cardBalanceRepository;

    public CardBalanceResource(CardBalanceService cardBalanceService, CardBalanceRepository cardBalanceRepository) {
        this.cardBalanceService = cardBalanceService;
        this.cardBalanceRepository = cardBalanceRepository;
    }


    @PostMapping("/card-balance")
    @TimeTraker
    public ResponseEntity<CardBalanceDTO> addBalance(@Valid @RequestBody CardBalanceDTO cardBalanceDTO) throws URISyntaxException {
        log.info("REST request to save CardBalance : {}", cardBalanceDTO);
        if (cardBalanceDTO.getId() != null) {
            throw new BadRequestAlertException("A new cardBalance cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CardBalanceDTO result = cardBalanceService.save(cardBalanceDTO);
        return ResponseEntity
                .created(new URI("/api/card-balance/" + result.getId()))
                .headers(XpnsHeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
                .body(result);
    }
    @GetMapping("/card-balance/{id}")
    @TimeTraker
    public ResponseEntity<CardBalanceResponseDTO> getBalance(@PathVariable Long id){
        log.info("REST request to get CardBalance : {}", id);
        Optional<CardBalanceResponseDTO> cardBalanceResDTO = cardBalanceService.findOne(id);
        return XpnsResponseUtil.wrapOrNotFound(cardBalanceResDTO);
    }

    @PutMapping("/card-balance/{id}")
    @TimeTraker
    public ResponseEntity<CardBalanceDTO> updateBalance(@PathVariable(value = "id", required = false) final Long id,
                                                        @NotNull @RequestBody CardBalanceDTO cardBalanceDTO){
        if (!cardBalanceRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }
        log.info("REST request to update CardBalance : {}", id);
        Optional<CardBalanceDTO> updatedCardBalanceDTO = cardBalanceService.update(cardBalanceDTO);

        return XpnsResponseUtil.wrapOrNotFound(
                updatedCardBalanceDTO,
                XpnsHeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, cardBalanceDTO.getId().toString())
        );

    }

}
