package com.zaggle.xpns.transactions.config;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.xpns.transactions.config.CommanProperties.Logstash;

import ch.qos.logback.classic.LoggerContext;
import net.logstash.logback.appender.LogstashTcpSocketAppender;
import net.logstash.logback.encoder.LogstashEncoder;
import net.logstash.logback.stacktrace.ShortenedThrowableConverter;

@Configuration
public class LoggingConfiguration {

	private static final Logger log = LoggerFactory.getLogger(LoggingConfiguration.class);
	
	public LoggingConfiguration(@Value("${spring.application.name}") String appName,
			@Value("${server.port}") String serverPort, CommanProperties commanProperties, ObjectMapper mapper)
			throws JsonProcessingException {
		LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();

		Map<String, String> map = new HashMap<>();
		String hostname = System.getenv("HOSTNAME");
		if (null != hostname) {
			map.put("host_name", hostname);
		}
		map.put("app_name", appName);
		map.put("app_port", serverPort);
		String customFields = mapper.writeValueAsString(map);

		Logstash ls = commanProperties.getLogs().getLogstash();
		
		System.out.println(ls.isEnabled());
		System.out.println(ls.getHost());
		System.out.println(ls.getPort());

		if (ls.isEnabled()) {
			
			addLogstashTcpSocketAppender(context, customFields, ls);
		}

	}

	public static void addLogstashTcpSocketAppender(LoggerContext context, String customFields, Logstash ls ) {
		log.info("Initializing Logstash loggingProperties...");

//  documentation is available at: https://github.com/logstash/logstash-logback-encoder
		// below localhost , port , buffer has to read dynamically, also add logic to
		// enable disable logshash

		LogstashTcpSocketAppender logstashAppender = new LogstashTcpSocketAppender();
		logstashAppender.addDestinations(new InetSocketAddress(ls.getHost(), ls.getPort()));
		logstashAppender.setContext(context);
		logstashAppender.setEncoder(logstashEncoder(customFields));
		logstashAppender.setName("ASYNC_LOGSTASH");
		logstashAppender.setRingBufferSize(ls.getRingBufferSize());
		logstashAppender.start();

		context.getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME).addAppender(logstashAppender);
	}

	private static LogstashEncoder logstashEncoder(String customFields) {
		LogstashEncoder logstashEncoder = new LogstashEncoder();
		logstashEncoder.setThrowableConverter(throwableConverter());
		logstashEncoder.setCustomFields(customFields);
		return logstashEncoder;
	}

	private static ShortenedThrowableConverter throwableConverter() {
		ShortenedThrowableConverter throwableConverter = new ShortenedThrowableConverter();
		throwableConverter.setRootCauseFirst(true);
		return throwableConverter;
	}

}
