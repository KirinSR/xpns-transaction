package com.zaggle.xpns.transactions.service.dto;

import org.json.simple.JSONObject;

public class ECollectionReqDTO {
    private String responseCode;
    private String responseDescription;
    private JSONObject responseIecData;

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseDescription() {
        return responseDescription;
    }

    public void setResponseDescription(String responseDescription) {
        this.responseDescription = responseDescription;
    }

    public JSONObject getResponseIecData() {
        return responseIecData;
    }

    public void setResponseIecData(JSONObject responseIecData) {
        this.responseIecData = responseIecData;
    }

    public ECollectionReqDTO(String responseCode, String responseDescription, JSONObject responseIecData) {
        this.responseCode = responseCode;
        this.responseDescription = responseDescription;
        this.responseIecData = responseIecData;
    }

    @Override
    public String toString() {
        return "ECollectionReqDTO{" +
                "responseCode='" + responseCode + '\'' +
                ", responseDescription='" + responseDescription + '\'' +
                ", responseIecData=" + responseIecData +
                '}';
    }
}
