package com.zaggle.xpns.transactions.web.rest;

import java.lang.reflect.Field;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.xpns.transactions.config.TimeTraker;
import com.zaggle.xpns.transactions.service.dto.TransactionApiResponse;
import com.zaggle.xpns.transactions.service.mapper.CardTransactionsMapper;
import org.json.simple.JSONObject;
import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.service.CardTransactionAddnInfoService;
import com.zaggle.xpns.transactions.service.dto.DownloadDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.zaggle.xpns.transactions.repository.CardTransactionsRepository;
import com.zaggle.xpns.transactions.service.CardTransactionsService;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsDTO;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsRequestDTO;
import com.zaggle.xpns.transactions.util.PaginationUtil;
import com.zaggle.xpns.transactions.util.XpnsHeaderUtil;
import com.zaggle.xpns.transactions.util.XpnsResponseUtil;
import com.zaggle.xpns.transactions.web.rest.errors.BadRequestAlertException;

/**
 * REST controller for managing {@link com.zaggle.xpns.transactions.domain.CardTransactions}.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@RestController
@RequestMapping("/api")
public class CardTransactionsResource {

    private final Logger log = LoggerFactory.getLogger(CardTransactionsResource.class);

    private static final String ENTITY_NAME = "transactionsCardTransactions";

    @Value("${xpns.clientApp.name}")
    private String applicationName;

    private final CardTransactionsService cardTransactionsService;

    private final CardTransactionsRepository cardTransactionsRepository;
    private final CardTransactionsMapper cardTransactionsMapper;
    private final CardTransactionAddnInfoService cardTransactionAddnInfoService;

    public CardTransactionsResource(
            CardTransactionsService cardTransactionsService,
            CardTransactionsRepository cardTransactionsRepository,
            CardTransactionsMapper cardTransactionsMapper, CardTransactionAddnInfoService cardTransactionAddnInfoService) {
        this.cardTransactionsService = cardTransactionsService;
        this.cardTransactionsRepository = cardTransactionsRepository;
        this.cardTransactionsMapper = cardTransactionsMapper;
        this.cardTransactionAddnInfoService = cardTransactionAddnInfoService;
    }

//    /**
//     * {@code POST  /card-transactions} : Create a new cardTransactions.
//     *
//     * @param cardTransactionsDTO the cardTransactionsDTO to create.
//     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new cardTransactionsDTO, or with status {@code 400 (Bad Request)} if the cardTransactions has already an ID.
//     * @throws URISyntaxException if the Location URI syntax is incorrect.
//     */
    @PostMapping("/card-transactions")
    @TimeTraker
    public ResponseEntity<CardTransactionsDTO> createCardTransactions(@Valid @RequestBody CardTransactionsRequestDTO cardTransactionsReqDTO)
        throws URISyntaxException {
        log.debug("REST request to save CardTransactions : {}", cardTransactionsReqDTO);
        if (cardTransactionsReqDTO.getId() != null) {
            throw new BadRequestAlertException("A new cardTransactions cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CardTransactionsDTO result = cardTransactionsService.save(cardTransactionsReqDTO);
        System.out.println(result);
        return ResponseEntity
            .created(new URI("/api/card-transactions/" + result.getId()))
            .headers(XpnsHeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /card-transactions/:id} : Updates an existing cardTransactions.
     *
     * @param id                  the id of the cardTransactionsDTO to save.
     * @param cardTransactionsDTO the cardTransactionsDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated cardTransactionsDTO,
     * or with status {@code 400 (Bad Request)} if the cardTransactionsDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the cardTransactionsDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/card-transactions/{id}")
    @TimeTraker
    public ResponseEntity<CardTransactionsDTO> updateCardTransactions(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody CardTransactionsDTO cardTransactionsDTO
    ) throws URISyntaxException {
        log.debug("REST request to update CardTransactions : {}, {}", id, cardTransactionsDTO);
        if (cardTransactionsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, cardTransactionsDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!cardTransactionsRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        CardTransactionsDTO result = cardTransactionsService.update(cardTransactionsDTO);
        return ResponseEntity
            .ok()
            .headers(XpnsHeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /card-transactions/:id} : Partial updates given fields of an existing cardTransactions, field will ignore if it is null
     *
     * @param id the id of the cardTransactionsDTO to save.
     * @param cardTransactionsDTO the cardTransactionsDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated cardTransactionsDTO,
     * or with status {@code 400 (Bad Request)} if the cardTransactionsDTO is not valid,
     * or with status {@code 404 (Not Found)} if the cardTransactionsDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the cardTransactionsDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/card-transactions/{id}", consumes = { "application/json", "application/merge-patch+json" })
    @TimeTraker
    public ResponseEntity<CardTransactionsDTO> partialUpdateCardTransactions(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody CardTransactionsDTO cardTransactionsDTO
    ) throws URISyntaxException, JsonProcessingException {
        log.debug("REST request to partial update CardTransactions partially : {}, {}", id, cardTransactionsDTO);
        if (cardTransactionsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, cardTransactionsDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!cardTransactionsRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<CardTransactionsDTO> result = cardTransactionsService.partialUpdate(cardTransactionsDTO);

        System.out.println("data being stored: "+result);

        return XpnsResponseUtil.wrapOrNotFound(
            result,
            XpnsHeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, cardTransactionsDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /card-transactions} : get all the cardTransactions.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of cardTransactions in body.
     */
    @GetMapping("/card-transactions")
    @TimeTraker
    public ResponseEntity<List<CardTransactionsDTO>> getAllCardTransactions(
        @org.springdoc.api.annotations.ParameterObject Pageable pageable
    ) {
        log.debug("REST request to get a page of CardTransactions");
        Page<CardTransactionsDTO> page = cardTransactionsService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.getPageHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /card-transactions/:id} : get the "id" cardTransactions.
     *
     * @param id the id of the cardTransactionsDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the cardTransactionsDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/card-transactions/{id}")
    @TimeTraker
    public ResponseEntity<CardTransactionsDTO> getCardTransactions(@PathVariable Long id) {
        log.debug("REST request to get CardTransactions : {}", id);
        Optional<CardTransactionsDTO> cardTransactionsDTO = cardTransactionsService.findOne(id);
        return XpnsResponseUtil.wrapOrNotFound(cardTransactionsDTO);
    }

    /**
     * {@code DELETE  /card-transactions/:id} : delete the "id" cardTransactions.
     *
     * @param id the id of the cardTransactionsDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/card-transactions/{id}")
    @TimeTraker
    public ResponseEntity<Void> deleteCardTransactions(@PathVariable Long id) {
        log.debug("REST request to delete CardTransactions : {}", id);
        cardTransactionsService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(XpnsHeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }

    @GetMapping("/card-transactionsByKitNo/{kitNo}")
    @TimeTraker
    public ResponseEntity<List<CardTransactions>> getAllCardTransactionsByKitNo(@PathVariable String kitNo, @org.springdoc.api.annotations.ParameterObject Pageable pageable){
        log.debug("REST request to delete CardTransactions : {}", kitNo);
        List<CardTransactions> transactions = cardTransactionsService.findAllTransactionsByKitNo(pageable, kitNo);
        return ResponseEntity.ok().body(transactions);
    }

    @GetMapping("/downloadTransactions/{kitNo}")
    @TimeTraker
    public ResponseEntity<DownloadDTO> downloadTransactions(@PathVariable("kitNo") String kitNo){
        if(!cardTransactionsRepository.existsByKitNo(kitNo))
            throw new EntityNotFoundException("Entity not found");
        List<CardTransactions> transactions = cardTransactionsService.findAllTransactionsByKitNoInRange(kitNo);
        HttpHeaders headers = new HttpHeaders();
        String downloadableEndpoint = "/api/transactionHistory/"+kitNo;
        DownloadDTO response = new DownloadDTO(HttpStatus.OK.value(), "Download Transaction History", downloadableEndpoint);
        headers.add("Content-Disposition", "attachment; filename=card_transactions.csv");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/transactionHistory/{kitNo}")
    @TimeTraker
    public ResponseEntity<byte[]> convertToCSV(@PathVariable String kitNo) {
        List<CardTransactions> transactions = cardTransactionsService.findAllTransactionsByKitNoInRange(kitNo);
        System.out.println(transactions);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=Transaction_History.csv");
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        // Define the separator for the CSV file
        StringBuilder csvFileBuilder = new StringBuilder();
        csvFileBuilder.append("\"id\",\"txnRef\",\"cardRefNo\",\"cardKitNo\",\"mobileNo\",\"cardType\",\"merchantLocation\",\"channel\",\"txnCurrency\",\"acquirerId\",\"network\",\"billingCurrency\",\"accqInstitutionCode\",\"corporate\",\"amount\",\"balance\",\"transactionType\",\"type\",\"txnTime\",\"beneficiaryName\",\"beneficiaryType\",\"beneficiaryId\",\"description\",\"txnOrigin\",\"otherPartyName\",\"otherPartyId\",\"transactionStatus\",\"customerWallet\",\"beneficiaryWallet\",\"externalTransactionId\",\"retrivalReferenceNo\",\"authCode\",\"billRefNo\",\"bankTid\",\"createdDt\",\"createdBy\",\"updatedBy\",\"updatedDt\"");
        csvFileBuilder.append("\n");
        for (CardTransactions cardTransaction : transactions) {
            csvFileBuilder.append(cardTransaction.getId())
                    .append(",")
                    .append(cardTransaction.getTxnRefNo())
                    .append(",")
                    .append(cardTransaction.getCardRefNo())
                    .append(",")
                    .append(cardTransaction.getKitNo())
                    .append(",")
                    .append(cardTransaction.getMobileNo())
                    .append(",")
                    .append(cardTransaction.getCardType())
                    .append(",")
                    .append(cardTransaction.getMerchantLocation())
                    .append(",")
                    .append(cardTransaction.getChannel())
                    .append(",")
                    .append(cardTransaction.getTxnCurrency())
                    .append(",")
                    .append(cardTransaction.getAcquirerId())
                    .append(",")
                    .append(cardTransaction.getNetwork())
                    .append(",")
                    .append(cardTransaction.getBillingCurrency())
                    .append(",")
                    .append(cardTransaction.getAccqInstitutionCode())
                    .append(",")
                    .append(cardTransaction.getCorporate())
                    .append(",")
                    .append(cardTransaction.getAmount())
                    .append(",")
                    .append(cardTransaction.getBalance())
                    .append(",")
                    .append(cardTransaction.getTransactionType())
                    .append(",")
                    .append(cardTransaction.getCrdr())
                    .append(",")
                    .append(cardTransaction.getTransactionDateTime())
                    .append(",")
                    .append(cardTransaction.getBeneficiaryName())
                    .append(",")
                    .append(cardTransaction.getTransactionType())
                    .append(",")
                    .append(cardTransaction.getBeneficiaryId())
                    .append(",")
                    .append(cardTransaction.getDescription())
                    .append(",")
                    .append(cardTransaction.getTxnOrigin())
                    .append(",")
                    .append(cardTransaction.getOtherPartyName())
                    .append(",")
                    .append(cardTransaction.getOtherPartyId())
                    .append(",")
                    .append(cardTransaction.getTxnStatus())
                    .append(",")
                    .append(cardTransaction.getCustomerWallet())
                    .append(",")
                    .append(cardTransaction.getBeneficiaryWallet())
                    .append(",")
                    .append(cardTransaction.getExtTxnId())
                    .append(",")
                    .append(cardTransaction.getRetrievalRefNo())
                    .append(",")
                    .append(cardTransaction.getAuthCode())
                    .append(",")
                    .append(cardTransaction.getBillRefNo())
                    .append(",")
                    .append(cardTransaction.getBankTid())
                    .append(",")
                    .append(cardTransaction.getCreatedDt())
                    .append(",")
                    .append(cardTransaction.getCreatedBy())
                    .append(",")
                    .append(cardTransaction.getUpdatedBy())
                    .append(",")
                    .append(cardTransaction.getUpdatedDt())
//                    .append(",")
//                    .append(cardTransaction.getCardTransactionsAddnInfo())
                    .append("\n");
        }


        byte[] in= csvFileBuilder.toString().getBytes();
//        return new ByteArrayInputStream(csvFileBuilder.toString().getBytes());
        return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_OCTET_STREAM).body(in);
    }


    @PostMapping("/webhook/createTransaction")
    @TimeTraker
    public ResponseEntity<TransactionApiResponse> insert(@Valid @RequestBody Map<String, Object> requestBody) throws JsonProcessingException{
        TransactionApiResponse response = cardTransactionsService.saveWebhook(requestBody);
        return ResponseEntity.ok(response);

    }

}
