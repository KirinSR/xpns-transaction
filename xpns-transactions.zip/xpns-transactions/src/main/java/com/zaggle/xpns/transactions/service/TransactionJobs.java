package com.zaggle.xpns.transactions.service;

import com.zaggle.xpns.transactions.constant.TransactionsConstants;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.domain.TransactionReport;
import com.zaggle.xpns.transactions.repository.CardTransactionsRepository;
import com.zaggle.xpns.transactions.repository.TransactionReportRepository;
import com.zaggle.xpns.transactions.service.dto.CardDetailsDTO;
import com.zaggle.xpns.transactions.service.dto.OrganisationDetailsDTO;
import com.zaggle.xpns.transactions.service.dto.TransactionReportQueryDTO;
import com.zaggle.xpns.transactions.service.impl.JobServiceImpl;
import com.zaggle.xpns.transactions.util.ElasticSearchUtil;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.opensearch.action.bulk.BulkRequest;
import org.opensearch.action.bulk.BulkResponse;
import org.opensearch.action.index.IndexRequest;
import org.opensearch.client.RequestOptions;
import org.opensearch.client.RestClient;
import org.opensearch.client.RestHighLevelClient;
import org.opensearch.client.indices.CreateIndexRequest;
import org.opensearch.client.indices.CreateIndexResponse;
import org.opensearch.client.indices.GetIndexRequest;
import org.opensearch.common.settings.Settings;
import org.opensearch.common.xcontent.XContentBuilder;
import org.opensearch.common.xcontent.XContentFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import javax.persistence.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Service
public class TransactionJobs {

    @Value("${internal-apis.get-card-emp-details-by-kitNo}")
    private String getCardEmpDetailsByKitNo;

    @Value("${internal-apis.get-org-details-by-orgId}")
    private String getOrgDetailsByOrgId;

    @PersistenceContext
    private EntityManager entityManager;
    @Autowired
    CardTransactionsRepository cardTransactionsRepo;
    @Autowired
    private TransactionReportRepository transactionReportRepository;

    private static  String url = null;



    private static final Logger log = LoggerFactory.getLogger(JobServiceImpl.class);
    static final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
    public TransactionJobs(@Value("${elasticsearch.kibana-app}") String url, @Value("${elasticsearch.username}") String username, @Value("${elasticsearch.password}") String password) {
        TransactionJobs.url = url;
        credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(username, password));

    }

//    private static final String FILE_NAME = "ecollection_transactions.csv";
//    private static final String FILE_PATH = "/path/to/your/file/";

//    @PostConstruct
//    @Scheduled(cron = "0 0 23 * * *")
    public void generateDailyTransactionsReport() throws SQLException, IOException, KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        List<TransactionReport> reports;

        //Scalar function
        LocalDate date = LocalDate.now();
        LocalDate prevDay = date.minusDays(1);
        List<Object[]> results = entityManager.
                createQuery("SELECT t.kitNo, SUM(CASE WHEN lower(t.crdr) = 'credit' THEN t.amount ELSE -t.amount END) as total_amount FROM CardTransactions t WHERE date(t.createdDt) > :prevDay GROUP BY t.kitNo").setParameter("prevDay", prevDay).getResultList();

                results.forEach(result -> System.out.println(Arrays.toString(result)));
                List<CardTransactions> todaysData = cardTransactionsRepo.findAllByCreatedDt(Instant.now());
        System.out.println("Todays data: "+todaysData);
        for(Object[] result : results){
            TransactionReport report = new TransactionReport();
            String kitNo= (String) result[0];
            Double b= (Double) result[1];
            System.out.println(prevDay);
            List<Object[]> prevDayData = entityManager.
                    createQuery("SELECT t.kitNo, t.balance FROM TransactionReport t WHERE t.kitNo = :kit_no AND t.reportTime = (SELECT MAX(reportTime) FROM TransactionReport WHERE kitNo = :kit_no )").setParameter("kit_no", kitNo).getResultList();

//            Double balance =
//            Object prevkitNo = prevDayData[0];
            Map<String, Double> prevDayDataMap = new HashMap<>();
            if (!prevDayData.isEmpty()) {
                for (Object[] row : prevDayData) {
                    prevDayDataMap.put((String) row[0], (Double) row[1]);
                }
            }

            System.out.println("prev transaction report: " + prevDayDataMap.keySet());

            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<CardDetailsDTO> cardDetailsResponse = restTemplate.exchange( getCardEmpDetailsByKitNo+kitNo, HttpMethod.GET, entity, CardDetailsDTO.class);
            CardDetailsDTO cardDetailsDTO = cardDetailsResponse.getBody();
            ResponseEntity<OrganisationDetailsDTO> responseEntityNew = restTemplate.exchange( getOrgDetailsByOrgId+cardDetailsDTO.getOrgId(), HttpMethod.GET, entity, OrganisationDetailsDTO.class);
            OrganisationDetailsDTO orgCategories = responseEntityNew.getBody();
//            System.out.println("OrgDetails: "+ orgCategories.getBusinessName());
//            System.out.println("User Id: "+ cardDetailsDTO.getEmpUserId());

            Double balance = prevDayDataMap.getOrDefault(kitNo, 0.0);
            report.setKitNo(kitNo);
            report.setTotalAmount(b);
            report.setReportTime(Instant.now());
            report.setBalance(b+ balance);
            report.setOrgId(orgCategories.getTenantId());
            report.setOrgName(orgCategories.getBusinessName());
            report.setUserId(cardDetailsDTO.getEmpUserId());
            transactionReportRepository.save(report);
            ElasticSearchUtil.main();
        }
        System.out.println("Transactions report Scheduler Excecuted");
    }

    public void generateDailyEcollectionReport() throws IOException, SQLException {
        RestHighLevelClient client = new RestHighLevelClient( RestClient.builder( new HttpHost(url, 80, "http") ).setHttpClientConfigCallback(httpClientBuilder -> httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider)));
        // Create an index
        String index = TransactionsConstants.ECOLLECTIONS_REPORT_INDEX; //clients_count
        CreateIndexRequest request = new CreateIndexRequest(index);
        GetIndexRequest reqIndex= new GetIndexRequest(index);
        if(!client.indices().exists(reqIndex,RequestOptions.DEFAULT)) {
            try {
                request.settings(Settings.builder()
                        .put("index.number_of_shards", 3)
                        .put("index.number_of_replicas", 4)
                );
                CreateIndexResponse createIndexResponse = client.indices().create(request, RequestOptions.DEFAULT);
                boolean acknowledged = createIndexResponse.isAcknowledged();
                boolean shardsAcknowledged = createIndexResponse.isShardsAcknowledged();
                log.info("Acknowledged: " + acknowledged);
                log.info("Shards Acknowledged: " + shardsAcknowledged);
            } catch (Exception ex) {
                log.error("Error in elasticsearch util::", ex);
            }
        }

        Connection connection = DriverManager.getConnection("jdbc:postgresql://dev-xpns-db.cety3rmbtz1s.ap-south-1.rds.amazonaws.com/transactions", "transactions", "u9C4aFAcUKh80Nc");
//        LocalDate yesterday = LocalDate.now().minusDays(1);
//        LocalDateTime yesterdayStart = yesterday.atStartOfDay();
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd 17:15:00");
        LocalDate yesterday = LocalDate.now().minusDays(1);
        LocalDate today = LocalDate.now();
        LocalDateTime yesterdayStart = yesterday.atStartOfDay();
        LocalDateTime todayEnd = today.atStartOfDay();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd 17:15:00");
        String query = "SELECT * FROM ecollection_transactions " +
                "WHERE created_dt >= '" + yesterdayStart.format(formatter) + "' " +
                "AND created_dt <= '" + todayEnd.format(formatter) + "'";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);

        int indx = 1;
        BulkRequest indexRequest = new BulkRequest(index);
        int columnCount = resultSet.getMetaData().getColumnCount();
        if (resultSet.next()) {
            do {
                XContentBuilder builder = XContentFactory.jsonBuilder().startObject();

                for (int i = 1; i <= columnCount; i++) {
                    String columnName = resultSet.getMetaData().getColumnName(i);
                    String columnValue = resultSet.getString(i);
                    builder.field(columnName, columnValue);
                }
                builder.endObject();
                indexRequest.add(new IndexRequest(index).id(resultSet.getString("id")).source(builder));
                indx++;
            }while (resultSet.next());
            BulkResponse indexResponse = client.bulk(indexRequest, RequestOptions.DEFAULT);
            log.info("Index response:: ", indexResponse);

        }
    }
}
