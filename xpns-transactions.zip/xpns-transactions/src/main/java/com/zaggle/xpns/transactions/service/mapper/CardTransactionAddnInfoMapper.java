package com.zaggle.xpns.transactions.service.mapper;

import com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoDTO;
import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoRequestDTO;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsRequestDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link CardTransactionAddnInfo} and its DTO {@link CardTransactionAddnInfoDTO}.
 */
@Mapper(componentModel = "spring")
public interface CardTransactionAddnInfoMapper extends EntityMapper<CardTransactionAddnInfoDTO, CardTransactionAddnInfo> {
    CardTransactionAddnInfo toEntity(CardTransactionAddnInfoRequestDTO cardTransactionAddnInfoReqDTO);
}
