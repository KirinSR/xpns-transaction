package com.zaggle.xpns.transactions.service.impl;

import java.io.DataInput;
import java.io.IOException;
import java.time.Instant;
import java.util.Optional;

import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoRequestDTO;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.repository.CardTransactionAddnInfoRepository;
import com.zaggle.xpns.transactions.repository.CardTransactionsRepository;
import com.zaggle.xpns.transactions.service.CardTransactionAddnInfoService;
import com.zaggle.xpns.transactions.service.dto.CardTransactionAddnInfoDTO;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsDTO;
import com.zaggle.xpns.transactions.service.mapper.CardTransactionAddnInfoMapper;
import com.zaggle.xpns.transactions.service.mapper.CardTransactionsMapper;

/**
 * Service Implementation for managing {@link CardTransactionAddnInfo}.
 */
@Service
@Transactional
public class CardTransactionAddnInfoServiceImpl implements CardTransactionAddnInfoService {

	private final Logger log = LoggerFactory.getLogger(CardTransactionAddnInfoServiceImpl.class);

	private final CardTransactionAddnInfoRepository cardTransactionAddnInfoRepository;

	private final CardTransactionsRepository cardTransactionsRepository;

	private final CardTransactionAddnInfoMapper cardTransactionAddnInfoMapper;

	private final CardTransactionsMapper cardTransactionsMapper;



	public CardTransactionAddnInfoServiceImpl(CardTransactionAddnInfoRepository cardTransactionAddnInfoRepository, CardTransactionsRepository cardTransactionsRepository, CardTransactionAddnInfoMapper cardTransactionAddnInfoMapper, CardTransactionsMapper cardTransactionsMapper) {
		this.cardTransactionAddnInfoRepository = cardTransactionAddnInfoRepository;
		this.cardTransactionsRepository = cardTransactionsRepository;
		this.cardTransactionAddnInfoMapper = cardTransactionAddnInfoMapper;
		this.cardTransactionsMapper = cardTransactionsMapper;
	}

	@Override
	public CardTransactionAddnInfoDTO save(CardTransactionAddnInfoRequestDTO cardTransactionAddnInfoReqDTO) {
		log.info("Request to save CardTransactionAddnInfo : {}", cardTransactionAddnInfoReqDTO);
		CardTransactionAddnInfo cardTransactionAddnInfo = cardTransactionAddnInfoMapper
				.toEntity(cardTransactionAddnInfoReqDTO);
		cardTransactionAddnInfo.setCreatedDt(Instant.now());
		cardTransactionAddnInfo = cardTransactionAddnInfoRepository.save(cardTransactionAddnInfo);

		if (cardTransactionAddnInfo.getId() != null) {
			JSONObject json = cardTransactionAddnInfo.getJsonInfo();

			try {
				ObjectMapper mapper = new ObjectMapper();
				CardTransactionsDTO cardTransactionsDTO = mapper.readValue((DataInput) cardTransactionAddnInfo.getJsonInfo(),
						CardTransactionsDTO.class);

				CardTransactions cardTransactions = cardTransactionsMapper.toEntity(cardTransactionsDTO);

				cardTransactionsRepository.save(cardTransactions);
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		return cardTransactionAddnInfoMapper.toDto(cardTransactionAddnInfo);
	}

	@Override
	public CardTransactionAddnInfoDTO update(CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO) {
		log.info("Request to update CardTransactionAddnInfo : {}", cardTransactionAddnInfoDTO);

		String updatedBy = cardTransactionAddnInfoDTO.getUpdatedBy();
		cardTransactionAddnInfoDTO.setUpdatedDt(Instant.now());
		cardTransactionAddnInfoDTO.setUpdatedBy(updatedBy);
		CardTransactionAddnInfo cardTransactionAddnInfo = cardTransactionAddnInfoMapper
				.toEntity(cardTransactionAddnInfoDTO);
		cardTransactionAddnInfo = cardTransactionAddnInfoRepository.save(cardTransactionAddnInfo);
		return cardTransactionAddnInfoMapper.toDto(cardTransactionAddnInfo);
	}

	@Override
	public Optional<CardTransactionAddnInfoDTO> partialUpdate(CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO) {
		log.info("Request to partially update CardTransactionAddnInfo : {}", cardTransactionAddnInfoDTO);
		String updatedBy = cardTransactionAddnInfoDTO.getUpdatedBy();
		cardTransactionAddnInfoDTO.setUpdatedBy(updatedBy);
		cardTransactionAddnInfoDTO.setUpdatedDt(Instant.now());

		return cardTransactionAddnInfoRepository.findById(cardTransactionAddnInfoDTO.getId())
				.map(existingCardTransactionAddnInfo -> {
					cardTransactionAddnInfoMapper.partialUpdate(existingCardTransactionAddnInfo,
							cardTransactionAddnInfoDTO);

					return existingCardTransactionAddnInfo;
				}).map(cardTransactionAddnInfoRepository::save).map(cardTransactionAddnInfoMapper::toDto);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<CardTransactionAddnInfoDTO> findAll(Pageable pageable) {
		log.info("Request to get all CardTransactionAddnInfos");
		return cardTransactionAddnInfoRepository.findAll(pageable).map(cardTransactionAddnInfoMapper::toDto);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<CardTransactionAddnInfoDTO> findOne(Long id) {
		log.info("Request to get CardTransactionAddnInfo : {}", id);
		return cardTransactionAddnInfoRepository.findById(id).map(cardTransactionAddnInfoMapper::toDto);
	}

	@Override
	public void delete(Long id) {
		log.info("Request to delete CardTransactionAddnInfo : {}", id);
		cardTransactionAddnInfoRepository.deleteById(id);
	}
}
