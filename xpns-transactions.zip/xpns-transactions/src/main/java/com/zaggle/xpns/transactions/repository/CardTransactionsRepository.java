package com.zaggle.xpns.transactions.repository;

import com.zaggle.xpns.transactions.domain.CardTransactions;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Spring Data JPA repository for the CardTransactions entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CardTransactionsRepository extends JpaRepository<CardTransactions, Long>, JpaSpecificationExecutor<CardTransactions> {
    List<CardTransactions> findAllByCreatedDt(Instant creationDateTime);

    @Query(value = "select t.* from card_transactions t where t.card_kit_no= :kitNo", nativeQuery = true)
    List<CardTransactions> findAllByCardKitNo(Pageable pageable, @Param("kitNo") String kitNo);

    @Query(value = "SELECT t.* FROM card_transactions t WHERE t.card_kit_no= :kitNo and to_timestamp(t.txn_time) >= to_timestamp(extract(epoch from date_trunc('day', TO_DATE(:currentDate, 'YYYY-MM-DD') - interval '90 days')))", nativeQuery = true)
    Optional<List<CardTransactions>> findAllByKitNoInRange(@Param("kitNo") String kitNo, @Param("currentDate") LocalDate currentDate);

    Boolean existsByKitNo(String kitNo);

//    Optional<List<CardTransactions>> findByCreatedDt(Instant prevDay);

    //    @Query("select Trt.card_ref_no as cardRef, SUM(case WHEN transaction_type = 'Credit' THEN amount ELSE -amount END) as total_amount from card_transactions t where cast(t.created_dt as text) > :creationDateTime group by t.card_ref_no;")

}
