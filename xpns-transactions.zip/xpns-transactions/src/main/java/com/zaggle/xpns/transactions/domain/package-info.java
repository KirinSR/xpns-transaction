/**
 * JPA domain objects.
 */
package com.zaggle.xpns.transactions.domain;
