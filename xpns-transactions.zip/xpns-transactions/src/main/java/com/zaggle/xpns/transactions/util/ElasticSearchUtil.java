package com.zaggle.xpns.transactions.util;

import com.zaggle.xpns.transactions.constant.TransactionsConstants;
import com.zaggle.xpns.transactions.service.TransactionJobs;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.opensearch.action.bulk.BulkRequest;
import org.opensearch.action.bulk.BulkResponse;
import org.opensearch.action.index.IndexRequest;
import org.opensearch.client.RequestOptions;
import org.opensearch.client.RestClient;
import org.opensearch.client.RestHighLevelClient;
import org.opensearch.client.indices.CreateIndexResponse;
import org.opensearch.client.indices.GetIndexRequest;
import org.opensearch.common.settings.Settings;
import org.opensearch.client.indices.CreateIndexRequest;
import org.opensearch.common.xcontent.XContentBuilder;
import org.opensearch.common.xcontent.XContentFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import java.io.IOException;
import java.security.*;
import java.sql.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class ElasticSearchUtil {
    private static String url = null;
    static final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();

    public ElasticSearchUtil(@Value("${elasticsearch.kibana-app}") String url, @Value("${elasticsearch.username}") String username, @Value("${elasticsearch.password}") String password) { ElasticSearchUtil.url = url; credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(username, password)); }

    private static final Logger log = LoggerFactory.getLogger(ElasticSearchUtil.class);
    public static void main() throws IOException, KeyStoreException, NoSuchAlgorithmException, KeyManagementException, SQLException {
        RestHighLevelClient client = new RestHighLevelClient( RestClient.builder( new HttpHost(url, 80, "http") ).setHttpClientConfigCallback(httpClientBuilder -> httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider)));
        // Create an index
         String index = TransactionsConstants.ELKINDEX; //clients_count
        CreateIndexRequest request = new CreateIndexRequest(index);
        GetIndexRequest reqIndex= new GetIndexRequest(index);
        if(!client.indices().exists(reqIndex,RequestOptions.DEFAULT)) {
            try {
                request.settings(Settings.builder()
                        .put("index.number_of_shards", 3)
                        .put("index.number_of_replicas", 4)
                );
                CreateIndexResponse createIndexResponse = client.indices().create(request, RequestOptions.DEFAULT);
                boolean acknowledged = createIndexResponse.isAcknowledged();
                boolean shardsAcknowledged = createIndexResponse.isShardsAcknowledged();
                log.info("Acknowledged: " + acknowledged);
                log.info("Shards Acknowledged: " + shardsAcknowledged);
            } catch (Exception ex) {
                log.error("Error in elasticsearch util::", ex);
            }
        }
        Connection connection = DriverManager.getConnection("jdbc:postgresql://dev-xpns-db.cety3rmbtz1s.ap-south-1.rds.amazonaws.com/transactions","transactions","u9C4aFAcUKh80Nc");
        LocalDate yesterday = LocalDate.now().minusDays(1);
        LocalDateTime yesterdayStart = yesterday.atStartOfDay();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        Instant now = Instant.now();
        LocalDate today =LocalDate.now();
        LocalDateTime todayStart = today.atStartOfDay();
//        pstmt.setDate(1, new java.sql.Date(now.toEpochMilli()));
        String query = "select kit_no, total_amount, balance, org_name, user_id from transaction_report where report_time >='"+ todayStart.format(formatter)+"'";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        int indx = 1;
        BulkRequest indexRequest = new BulkRequest(index);
        int columnCount = resultSet.getMetaData().getColumnCount();
        while(resultSet.next()) {
//            System.out.println("ResultSet: "+ resultSet.getString("kit_no"));

            XContentBuilder builder = XContentFactory.jsonBuilder().startObject();
            // iterate over the columns and add them to the document data
            for (int i = 1; i <= columnCount; i++) {
            String columnName = resultSet.getMetaData().getColumnName(i);
            String columnValue = resultSet.getString(i);
            builder.field(columnName, columnValue);
        }
        builder.endObject();
        indexRequest.add(new IndexRequest(index).id(resultSet.getString(1)).source(builder));
        indx++;
    }
    BulkResponse indexResponse = client.bulk(indexRequest, RequestOptions.DEFAULT);
        log.info("Index response:: ",indexResponse);
        client.close();
}
}
