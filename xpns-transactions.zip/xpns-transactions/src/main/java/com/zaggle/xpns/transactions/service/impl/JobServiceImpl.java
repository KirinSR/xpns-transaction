package com.zaggle.xpns.transactions.service.impl;

import com.zaggle.xpns.transactions.constant.TransactionsConstants;
import com.zaggle.xpns.transactions.domain.ECollectionTransactions;
import com.zaggle.xpns.transactions.repository.EcollectionTransactionsRepository;
import com.zaggle.xpns.transactions.service.TransactionJobs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Service
public class JobServiceImpl {

    @Value("${internal-apis.send-notification-email}")
    private String sendNotificationEmail;

    private final Logger log = LoggerFactory.getLogger(JobServiceImpl.class);

    @Autowired
    private final TransactionJobs transactionJobs;

    @Autowired
    private final EcollectionTransactionsRepository ecollectionTransactionsRepository;

    public JobServiceImpl(TransactionJobs transactionJobs, EcollectionTransactionsRepository ecollectionTransactionsRepository) {
        this.transactionJobs = transactionJobs;
        this.ecollectionTransactionsRepository = ecollectionTransactionsRepository;
    }

    @Scheduled(cron = "0 0 23 * * *")
    public void sendTransactionsToELK() throws SQLException, IOException, KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date now = new Date();
        String strDate = sdf.format(now);
//        ElasticsearchConnectUtil.main();
//        TransactionJobs transactionJobs = new TransactionJobs();
        transactionJobs.generateDailyTransactionsReport();
        log.info("Sending transaction data to elasticsearch at:: " + strDate);
    }

    @Scheduled(cron = "0 15 17 * * *")
    public void sendEcollectionReportsToELK() throws SQLException, IOException, KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date now = new Date();
        String strDate = sdf.format(now);
        transactionJobs.generateDailyEcollectionReport();
        log.info("Sending ECollection data to elasticsearch at:: " + strDate);
        LocalDate yesterday = LocalDate.now().minusDays(1);
        LocalDate today = LocalDate.now();
        LocalDateTime yesterdayStart = yesterday.atTime(17, 15);
        LocalDateTime todayEnd = today.atTime(17, 15);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        String yesterdayStartFormatted = yesterdayStart.format(formatter);
        String todayEndFormatted = todayEnd.format(formatter);
        if (!ecollectionTransactionsRepository.findAllInRange(yesterdayStartFormatted, todayEndFormatted).isEmpty()) {
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            String templateId = "XPNS_DYNAMIC_EMAIL_TEMPLATE";
            List<String> receivers = Arrays.asList("xpnsfinance@yopmail.com");
            List<String> args = Arrays.asList(TransactionsConstants.ECOLLECTION_REPORTS_MAIL_SUBJECT, TransactionsConstants.ECOLLECTION_DAILY_REPORT_TEMPLATE);

            Map<String, Object> payload = new HashMap<>();
            payload.put("templateId", templateId);
            payload.put("receivers", receivers);
            payload.put("args", args);

            HttpEntity<Map<String, Object>> notificationMailEntity = new HttpEntity<>(payload, httpHeaders);
            System.out.println("Notification Entity: " + notificationMailEntity.getBody());
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<Object> response = restTemplate.exchange(sendNotificationEmail, HttpMethod.POST, notificationMailEntity, Object.class);
            if (response.getStatusCodeValue() == 200)
                log.info("Ecollection report sent to mail");
            else
                log.error("Failed to send Ecollection Report: " + (String) response.getBody());
        }
    }

}
