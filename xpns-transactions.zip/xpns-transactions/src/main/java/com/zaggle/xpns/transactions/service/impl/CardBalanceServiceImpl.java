package com.zaggle.xpns.transactions.service.impl;

import com.fasterxml.jackson.databind.util.BeanUtil;
import com.zaggle.xpns.transactions.domain.CardBalance;
import com.zaggle.xpns.transactions.repository.CardBalanceRepository;
import com.zaggle.xpns.transactions.repository.CardTransactionsRepository;
import com.zaggle.xpns.transactions.service.CardBalanceService;
import com.zaggle.xpns.transactions.service.dto.CardBalanceDTO;
import com.zaggle.xpns.transactions.service.dto.CardBalanceResponseDTO;
import com.zaggle.xpns.transactions.service.mapper.CardBalanceMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.time.Instant;
import java.util.Optional;

@Service
@Transactional
public class CardBalanceServiceImpl implements CardBalanceService {
    private final CardBalanceRepository cardBalanceRepository;
    private final CardBalanceMapper cardBalanceMapper;
    private final org.slf4j.Logger log = LoggerFactory.getLogger(CardTransactionsServiceImpl.class);
    private final CardTransactionsRepository cardTransactionsRepository;

    public CardBalanceServiceImpl(CardBalanceRepository cardBalanceRepository, CardBalanceMapper cardBalanceMapper,
                                  CardTransactionsRepository cardTransactionsRepository) {
        this.cardBalanceRepository = cardBalanceRepository;
        this.cardBalanceMapper = cardBalanceMapper;
        this.cardTransactionsRepository = cardTransactionsRepository;
    }

    @Override
    public CardBalanceDTO save(CardBalanceDTO cardBalanceDTO) {

        CardBalance cardBalance = cardBalanceMapper.toEntity(cardBalanceDTO);
        cardBalance.setCreatedDt(Instant.now());
        cardBalance = cardBalanceRepository.save(cardBalance);
        System.out.println(""+cardBalance.getCreatedDt());
        return cardBalanceMapper.toDto(cardBalance);
    }

    @Override
    public Optional<CardBalanceResponseDTO> findOne(Long id) {
        CardBalanceResponseDTO cardResDto = new CardBalanceResponseDTO();

       CardBalance cardBalance = new CardBalance();
              cardBalance = cardBalanceRepository.findById(id).orElseThrow(()->new EntityNotFoundException("This id is not found"));
       cardResDto.setBalance(cardBalance.getBalance());
       cardResDto.setUpdatedBy(cardBalance.getUpdatedBy());

        return Optional.of(cardResDto);
    }

    @Override
    public Optional<CardBalanceDTO> update(CardBalanceDTO cardBalanceDTO) {
        String updatedBy = cardBalanceDTO.getUpdatedBy();
        cardBalanceDTO.setUpdatedDt(Instant.now());
        cardBalanceDTO.setUpdatedBy(updatedBy);
        return cardBalanceRepository
                .findById(cardBalanceDTO.getId())
                .map(existingCardTransactions -> {
                    cardBalanceMapper.partialUpdate(existingCardTransactions, cardBalanceDTO);

                    return existingCardTransactions;
                })
                .map(cardBalanceRepository::save)
                .map(cardBalanceMapper::toDto);
    }
}
