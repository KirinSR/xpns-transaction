##EKS 

* Install kubectl
* Install Chocolatey
* Install eksctl


kubectl apply -f .\deploy-template-demo.yml

kubectl apply -f .\service-template-demo.yml

kubectl create -f .\kong.yml

kubectl apply -f .\ingress-rule.yml


Access : curl -i aab575defedd040c0af37d8d36964e96-278ed2b0da56d638.elb.ap-northeast-1.amazonaws.com/api/hello-expense-apis/

Ref Link

Kong : https://docs.konghq.com/kubernetes-ingress-controller/latest/deployment/eks/


