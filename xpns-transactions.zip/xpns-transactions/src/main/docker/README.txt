# To start postgres

```docker-compose -f postgresql.yml up```