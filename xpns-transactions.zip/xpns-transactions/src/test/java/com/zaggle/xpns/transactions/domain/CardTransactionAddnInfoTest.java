package com.zaggle.xpns.transactions.domain;

import static org.assertj.core.api.Assertions.assertThat;

import com.zaggle.xpns.transactions.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class CardTransactionAddnInfoTest {

//    @Test
//    void equalsVerifier() throws Exception {
//        TestUtil.equalsVerifier(CardTransactionAddnInfo.class);
//        CardTransactionAddnInfo cardTransactionAddnInfo1 = new CardTransactionAddnInfo();
//        cardTransactionAddnInfo1.setId(1L);
//        CardTransactionAddnInfo cardTransactionAddnInfo2 = new CardTransactionAddnInfo();
//        cardTransactionAddnInfo2.setId(cardTransactionAddnInfo1.getId());
//        assertThat(cardTransactionAddnInfo1).isEqualTo(cardTransactionAddnInfo2);
//        cardTransactionAddnInfo2.setId(2L);
//        assertThat(cardTransactionAddnInfo1).isNotEqualTo(cardTransactionAddnInfo2);
//        cardTransactionAddnInfo1.setId(null);
//        assertThat(cardTransactionAddnInfo1).isNotEqualTo(cardTransactionAddnInfo2);
//    }
}
