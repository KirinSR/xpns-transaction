package com.zaggle.xpns.transactions.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.zaggle.xpns.transactions.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class CardTransactionsDTOTest {

//    @Test
//    void dtoEqualsVerifier() throws Exception {
//        TestUtil.equalsVerifier(CardTransactionsDTO.class);
//        CardTransactionsDTO cardTransactionsDTO1 = new CardTransactionsDTO();
//        cardTransactionsDTO1.setId(1L);
//        CardTransactionsDTO cardTransactionsDTO2 = new CardTransactionsDTO();
//        assertThat(cardTransactionsDTO1).isNotEqualTo(cardTransactionsDTO2);
//        cardTransactionsDTO2.setId(cardTransactionsDTO1.getId());
//        assertThat(cardTransactionsDTO1).isEqualTo(cardTransactionsDTO2);
//        cardTransactionsDTO2.setId(2L);
//        assertThat(cardTransactionsDTO1).isNotEqualTo(cardTransactionsDTO2);
//        cardTransactionsDTO1.setId(null);
//        assertThat(cardTransactionsDTO1).isNotEqualTo(cardTransactionsDTO2);
//    }
}
