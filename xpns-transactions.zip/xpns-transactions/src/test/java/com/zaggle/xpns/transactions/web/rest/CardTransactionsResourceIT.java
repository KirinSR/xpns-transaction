package com.zaggle.xpns.transactions.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.zaggle.xpns.transactions.IntegrationTest;
import com.zaggle.xpns.transactions.domain.CardTransactionAddnInfo;
import com.zaggle.xpns.transactions.domain.CardTransactions;
import com.zaggle.xpns.transactions.repository.CardTransactionsRepository;
import com.zaggle.xpns.transactions.service.dto.CardTransactionsDTO;
import com.zaggle.xpns.transactions.service.mapper.CardTransactionsMapper;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import javax.persistence.EntityManager;
import javax.validation.constraints.NotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link CardTransactionsResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class CardTransactionsResourceIT {

    private static final String DEFAULT_TX_REF = "AAAAAAAAAA";
    private static final String UPDATED_TX_REF = "BBBBBBBBBB";

    private static final Double DEFAULT_AMOUNT = 1D;
    private static final Double UPDATED_AMOUNT = 2D;

    private static final Double DEFAULT_BALANCE = 1D;
    private static final Double UPDATED_BALANCE = 2D;

    private static final String DEFAULT_TRANSACTION_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_TRANSACTION_TYPE = "BBBBBBBBBB";

    private static final String DEFAULT_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_TYPE = "BBBBBBBBBB";

    private static final Long DEFAULT_TIME = Instant.now().getEpochSecond();
    private static final Long UPDATED_TIME = Instant.now().getEpochSecond();

    private static final String DEFAULT_BENEFICIARY_NAME = "AAAAAAAAAA";
    private static final String UPDATED_BENEFICIARY_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_BENEFICIARY_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_BENEFICIARY_TYPE = "BBBBBBBBBB";

    private static final String DEFAULT_BENEFICIARY_ID = "AAAAAAAAAA";
    private static final String UPDATED_BENEFICIARY_ID = "BBBBBBBBBB";

    private static final String DEFAULT_DESCRIPTION = "AAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBBBBBBB";

    private static final String DEFAULT_TXN_ORIGIN = "AAAAAAAAAA";
    private static final String UPDATED_TXN_ORIGIN = "BBBBBBBBBB";

    private static final String DEFAULT_OTHER_PARTY_NAME = "AAAAAAAAAA";
    private static final String UPDATED_OTHER_PARTY_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_OTHER_PARTY_ID = "AAAAAAAAAA";
    private static final String UPDATED_OTHER_PARTY_ID = "BBBBBBBBBB";

    private static final String DEFAULT_TRANSACTION_STATUS = "AAAAAAAAAA";
    private static final String UPDATED_TRANSACTION_STATUS = "BBBBBBBBBB";

    private static final String DEFAULT_YOUR_WALLET = "AAAAAAAAAA";
    private static final String UPDATED_YOUR_WALLET = "BBBBBBBBBB";

    private static final String DEFAULT_BENEFICIARY_WALLET = "AAAAAAAAAA";
    private static final String UPDATED_BENEFICIARY_WALLET = "BBBBBBBBBB";

    private static final String DEFAULT_EXTERNAL_TRANSACTION_ID = "AAAAAAAAAA";
    private static final String UPDATED_EXTERNAL_TRANSACTION_ID = "BBBBBBBBBB";

    private static final String DEFAULT_RETRIVAL_REFERENCE_NO = "AAAAAAAAAA";
    private static final String UPDATED_RETRIVAL_REFERENCE_NO = "BBBBBBBBBB";

    private static final String DEFAULT_AUTH_CODE = "AAAAAAAAAA";
    private static final String UPDATED_AUTH_CODE = "BBBBBBBBBB";

    private static final String DEFAULT_BILL_REF_NO = "AAAAAAAAAA";
    private static final String UPDATED_BILL_REF_NO = "BBBBBBBBBB";

    private static final String DEFAULT_BANK_TID = "AAAAAAAAAA";
    private static final String UPDATED_BANK_TID = "BBBBBBBBBB";

    private static final String DEFAULT_CREATED_BY = "AAAAAAAAAA";
    private static final String UPDATED_CREATED_BY = "BBBBBBBBBB";

    private static final Instant DEFAULT_CREATED_DT = Instant.now();
    private static final Instant UPDATED_CREATED_DT = Instant.now();

    private static final LocalDate DEFAULT_UPDATED_DT = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_UPDATED_DT = LocalDate.now(ZoneId.systemDefault());

    private static final String DEFAULT_UPDATED_BY = "AAAAAAAAAA";
    private static final String UPDATED_UPDATED_BY = "BBBBBBBBBB";

    private static final Long DEFAULT_CARD_TRANSACTIONS_ADDN_INFO_ID = 1l;
    private static final Long UPDATED_CARD_TRANSACTIONS_ADDN_INFO_ID = 2l;

    private static final String ENTITY_API_URL = "/api/card-transactions";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong count = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private CardTransactionsRepository cardTransactionsRepository;

    @Autowired
    private CardTransactionsMapper cardTransactionsMapper;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restCardTransactionsMockMvc;

    private CardTransactions cardTransactions;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static CardTransactions createEntity(EntityManager em) {
        CardTransactions cardTransactions = CardTransactions.builder()
            .txnRefNo(DEFAULT_TX_REF)
            .amount(DEFAULT_AMOUNT)
            .balance(DEFAULT_BALANCE)
            .transactionType(DEFAULT_TRANSACTION_TYPE)
            .crdr(DEFAULT_TYPE)
            .transactionDateTime(DEFAULT_TIME)
            .beneficiaryName(DEFAULT_BENEFICIARY_NAME)
            .beneficiaryType(DEFAULT_BENEFICIARY_TYPE)
            .beneficiaryId(DEFAULT_BENEFICIARY_ID)
            .description(DEFAULT_DESCRIPTION)
            .txnOrigin(DEFAULT_TXN_ORIGIN)
            .otherPartyName(DEFAULT_OTHER_PARTY_NAME)
            .otherPartyId(DEFAULT_OTHER_PARTY_ID)
            .txnStatus(DEFAULT_TRANSACTION_STATUS)
            .customerWallet(DEFAULT_YOUR_WALLET)
            .beneficiaryWallet(DEFAULT_BENEFICIARY_WALLET)
            .extTxnId(DEFAULT_EXTERNAL_TRANSACTION_ID)
            .retrievalRefNo(DEFAULT_RETRIVAL_REFERENCE_NO)
            .authCode(DEFAULT_AUTH_CODE)
            .billRefNo(DEFAULT_BILL_REF_NO)
            .bankTid(DEFAULT_BANK_TID)
            // .createdBy(DEFAULT_CREATED_BY)
            // .createdDt(DEFAULT_CREATED_DT)
            // .updatedDt(DEFAULT_UPDATED_DT)
            // .updatedBy(DEFAULT_UPDATED_BY)
            .cardTransactionsAddnInfo(DEFAULT_CARD_TRANSACTIONS_ADDN_INFO_ID).build();
        return cardTransactions;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static CardTransactions createUpdatedEntity(EntityManager em) {
        CardTransactions cardTransactions = CardTransactions.builder()
            .txnRefNo(UPDATED_TX_REF)
            .amount(UPDATED_AMOUNT)
            .balance(UPDATED_BALANCE)
            .transactionType(UPDATED_TRANSACTION_TYPE)
            .crdr(UPDATED_TYPE)
            .transactionDateTime(UPDATED_TIME)
            .beneficiaryName(UPDATED_BENEFICIARY_NAME)
            .beneficiaryType(UPDATED_BENEFICIARY_TYPE)
            .beneficiaryId(UPDATED_BENEFICIARY_ID)
            .description(UPDATED_DESCRIPTION)
            .txnOrigin(UPDATED_TXN_ORIGIN)
            .otherPartyName(UPDATED_OTHER_PARTY_NAME)
            .otherPartyId(UPDATED_OTHER_PARTY_ID)
            .txnStatus(UPDATED_TRANSACTION_STATUS)
            .customerWallet(UPDATED_YOUR_WALLET)
            .beneficiaryWallet(UPDATED_BENEFICIARY_WALLET)
            .extTxnId(UPDATED_EXTERNAL_TRANSACTION_ID)
            .retrievalRefNo(UPDATED_RETRIVAL_REFERENCE_NO)
            .authCode(UPDATED_AUTH_CODE)
            .billRefNo(UPDATED_BILL_REF_NO)
            .bankTid(UPDATED_BANK_TID)
            // .createdBy(UPDATED_CREATED_BY)
            // .createdDt(UPDATED_CREATED_DT)
            // .updatedDt(UPDATED_UPDATED_DT)
            // .updatedBy(UPDATED_UPDATED_BY)
            .build();
        return cardTransactions;
    }

    @BeforeEach
    public void initTest() {
        cardTransactions = createEntity(em);
    }

    @Test
    @Transactional
    void createCardTransactions() throws Exception {
        int databaseSizeBeforeCreate = cardTransactionsRepository.findAll().size();
        // Create the CardTransactions
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);
        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isCreated());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeCreate + 1);
        CardTransactions testCardTransactions = cardTransactionsList.get(cardTransactionsList.size() - 1);
        assertThat(testCardTransactions.getTxnRefNo()).isEqualTo(DEFAULT_TX_REF);
        assertThat(testCardTransactions.getAmount()).isEqualTo(DEFAULT_AMOUNT);
        assertThat(testCardTransactions.getBalance()).isEqualTo(DEFAULT_BALANCE);
        assertThat(testCardTransactions.getTransactionType()).isEqualTo(DEFAULT_TRANSACTION_TYPE);
        assertThat(testCardTransactions.getCrdr()).isEqualTo(DEFAULT_TYPE);
        assertThat(testCardTransactions.getTransactionDateTime()).isEqualTo(DEFAULT_TIME);
        assertThat(testCardTransactions.getBeneficiaryName()).isEqualTo(DEFAULT_BENEFICIARY_NAME);
        assertThat(testCardTransactions.getBeneficiaryType()).isEqualTo(DEFAULT_BENEFICIARY_TYPE);
        assertThat(testCardTransactions.getBeneficiaryId()).isEqualTo(DEFAULT_BENEFICIARY_ID);
        assertThat(testCardTransactions.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testCardTransactions.getTxnOrigin()).isEqualTo(DEFAULT_TXN_ORIGIN);
        assertThat(testCardTransactions.getOtherPartyName()).isEqualTo(DEFAULT_OTHER_PARTY_NAME);
        assertThat(testCardTransactions.getOtherPartyId()).isEqualTo(DEFAULT_OTHER_PARTY_ID);
        assertThat(testCardTransactions.getTxnStatus()).isEqualTo(DEFAULT_TRANSACTION_STATUS);
        assertThat(testCardTransactions.getCustomerWallet()).isEqualTo(DEFAULT_YOUR_WALLET);
        assertThat(testCardTransactions.getBeneficiaryWallet()).isEqualTo(DEFAULT_BENEFICIARY_WALLET);
        assertThat(testCardTransactions.getExtTxnId()).isEqualTo(DEFAULT_EXTERNAL_TRANSACTION_ID);
        assertThat(testCardTransactions.getRetrievalRefNo()).isEqualTo(DEFAULT_RETRIVAL_REFERENCE_NO);
        assertThat(testCardTransactions.getAuthCode()).isEqualTo(DEFAULT_AUTH_CODE);
        assertThat(testCardTransactions.getBillRefNo()).isEqualTo(DEFAULT_BILL_REF_NO);
        assertThat(testCardTransactions.getBankTid()).isEqualTo(DEFAULT_BANK_TID);
        assertThat(testCardTransactions.getCreatedBy()).isEqualTo(DEFAULT_CREATED_BY);
        assertThat(testCardTransactions.getCreatedDt()).isEqualTo(DEFAULT_CREATED_DT);
        // assertThat(testCardTransactions.getUpdatedDt()).isEqualTo(DEFAULT_UPDATED_DT);
        // assertThat(testCardTransactions.getUpdatedBy()).isEqualTo(DEFAULT_UPDATED_BY);
        assertThat(testCardTransactions.getCardTransactionsAddnInfo()).isEqualTo(DEFAULT_CARD_TRANSACTIONS_ADDN_INFO_ID);
    }

    @Test
    @Transactional
    void createCardTransactionsWithExistingId() throws Exception {
        // Create the CardTransactions with an existing ID
        cardTransactions.setId(1L);
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        int databaseSizeBeforeCreate = cardTransactionsRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkTxRefIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setTxnRefNo(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkAmountIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setAmount(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkBalanceIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setBalance(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkTransactionTypeIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setTransactionType(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkTimeIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setTransactionDateTime(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkBeneficiaryNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setBeneficiaryName(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkOtherPartyNameIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setOtherPartyName(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkTransactionStatusIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setTxnStatus(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkExternalTransactionIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setExtTxnId(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkRetrivalReferenceNoIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setRetrievalRefNo(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkAuthCodeIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setAuthCode(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkBillRefNoIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setBillRefNo(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkBankTidIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setBankTid(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void checkCardTransactionsAddnInfoIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = cardTransactionsRepository.findAll().size();
        // set the field null
        cardTransactions.setCardTransactionsAddnInfo(null);

        // Create the CardTransactions, which fails.
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        restCardTransactionsMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllCardTransactions() throws Exception {
        // Initialize the database
        cardTransactionsRepository.saveAndFlush(cardTransactions);

        // Get all the cardTransactionsList
        restCardTransactionsMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(cardTransactions.getId().intValue())))
            .andExpect(jsonPath("$.[*].txRef").value(hasItem(DEFAULT_TX_REF)))
            .andExpect(jsonPath("$.[*].amount").value(hasItem(DEFAULT_AMOUNT.doubleValue())))
            .andExpect(jsonPath("$.[*].balance").value(hasItem(DEFAULT_BALANCE.doubleValue())))
            .andExpect(jsonPath("$.[*].transactionType").value(hasItem(DEFAULT_TRANSACTION_TYPE)))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE)))
            .andExpect(jsonPath("$.[*].time").value(hasItem(DEFAULT_TIME.toString())))
            .andExpect(jsonPath("$.[*].beneficiaryName").value(hasItem(DEFAULT_BENEFICIARY_NAME)))
            .andExpect(jsonPath("$.[*].beneficiaryType").value(hasItem(DEFAULT_BENEFICIARY_TYPE)))
            .andExpect(jsonPath("$.[*].beneficiaryId").value(hasItem(DEFAULT_BENEFICIARY_ID)))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION)))
            .andExpect(jsonPath("$.[*].txnOrigin").value(hasItem(DEFAULT_TXN_ORIGIN)))
            .andExpect(jsonPath("$.[*].otherPartyName").value(hasItem(DEFAULT_OTHER_PARTY_NAME)))
            .andExpect(jsonPath("$.[*].otherPartyId").value(hasItem(DEFAULT_OTHER_PARTY_ID)))
            .andExpect(jsonPath("$.[*].transactionStatus").value(hasItem(DEFAULT_TRANSACTION_STATUS)))
            .andExpect(jsonPath("$.[*].yourWallet").value(hasItem(DEFAULT_YOUR_WALLET)))
            .andExpect(jsonPath("$.[*].beneficiaryWallet").value(hasItem(DEFAULT_BENEFICIARY_WALLET)))
            .andExpect(jsonPath("$.[*].externalTransactionId").value(hasItem(DEFAULT_EXTERNAL_TRANSACTION_ID)))
            .andExpect(jsonPath("$.[*].retrivalReferenceNo").value(hasItem(DEFAULT_RETRIVAL_REFERENCE_NO)))
            .andExpect(jsonPath("$.[*].authCode").value(hasItem(DEFAULT_AUTH_CODE)))
            .andExpect(jsonPath("$.[*].billRefNo").value(hasItem(DEFAULT_BILL_REF_NO)))
            .andExpect(jsonPath("$.[*].bankTid").value(hasItem(DEFAULT_BANK_TID)))
            .andExpect(jsonPath("$.[*].createdBy").value(hasItem(DEFAULT_CREATED_BY)))
            .andExpect(jsonPath("$.[*].createdDt").value(hasItem(DEFAULT_CREATED_DT.toString())))
            .andExpect(jsonPath("$.[*].updatedDt").value(hasItem(DEFAULT_UPDATED_DT.toString())))
            .andExpect(jsonPath("$.[*].updatedBy").value(hasItem(DEFAULT_UPDATED_BY)))
            .andExpect(jsonPath("$.[*].cardTransactionsAddnInfoId").value(hasItem(DEFAULT_CARD_TRANSACTIONS_ADDN_INFO_ID)));
    }

    @Test
    @Transactional
    void getCardTransactions() throws Exception {
        // Initialize the database
        cardTransactionsRepository.saveAndFlush(cardTransactions);

        // Get the cardTransactions
        restCardTransactionsMockMvc
            .perform(get(ENTITY_API_URL_ID, cardTransactions.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(cardTransactions.getId().intValue()))
            .andExpect(jsonPath("$.txRef").value(DEFAULT_TX_REF))
            .andExpect(jsonPath("$.amount").value(DEFAULT_AMOUNT.doubleValue()))
            .andExpect(jsonPath("$.balance").value(DEFAULT_BALANCE.doubleValue()))
            .andExpect(jsonPath("$.transactionType").value(DEFAULT_TRANSACTION_TYPE))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE))
            .andExpect(jsonPath("$.time").value(DEFAULT_TIME.toString()))
            .andExpect(jsonPath("$.beneficiaryName").value(DEFAULT_BENEFICIARY_NAME))
            .andExpect(jsonPath("$.beneficiaryType").value(DEFAULT_BENEFICIARY_TYPE))
            .andExpect(jsonPath("$.beneficiaryId").value(DEFAULT_BENEFICIARY_ID))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION))
            .andExpect(jsonPath("$.txnOrigin").value(DEFAULT_TXN_ORIGIN))
            .andExpect(jsonPath("$.otherPartyName").value(DEFAULT_OTHER_PARTY_NAME))
            .andExpect(jsonPath("$.otherPartyId").value(DEFAULT_OTHER_PARTY_ID))
            .andExpect(jsonPath("$.transactionStatus").value(DEFAULT_TRANSACTION_STATUS))
            .andExpect(jsonPath("$.yourWallet").value(DEFAULT_YOUR_WALLET))
            .andExpect(jsonPath("$.beneficiaryWallet").value(DEFAULT_BENEFICIARY_WALLET))
            .andExpect(jsonPath("$.externalTransactionId").value(DEFAULT_EXTERNAL_TRANSACTION_ID))
            .andExpect(jsonPath("$.retrivalReferenceNo").value(DEFAULT_RETRIVAL_REFERENCE_NO))
            .andExpect(jsonPath("$.authCode").value(DEFAULT_AUTH_CODE))
            .andExpect(jsonPath("$.billRefNo").value(DEFAULT_BILL_REF_NO))
            .andExpect(jsonPath("$.bankTid").value(DEFAULT_BANK_TID))
            .andExpect(jsonPath("$.createdBy").value(DEFAULT_CREATED_BY))
            .andExpect(jsonPath("$.createdDt").value(DEFAULT_CREATED_DT.toString()))
            .andExpect(jsonPath("$.updatedDt").value(DEFAULT_UPDATED_DT.toString()))
            .andExpect(jsonPath("$.updatedBy").value(DEFAULT_UPDATED_BY))
            .andExpect(jsonPath("$.cardTransactionsAddnInfoId").value(DEFAULT_CARD_TRANSACTIONS_ADDN_INFO_ID));
    }

    @Test
    @Transactional
    void getNonExistingCardTransactions() throws Exception {
        // Get the cardTransactions
        restCardTransactionsMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingCardTransactions() throws Exception {
        // Initialize the database
        cardTransactionsRepository.saveAndFlush(cardTransactions);

        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();

        // Update the cardTransactions
        CardTransactions updatedCardTransactions = cardTransactionsRepository.findById(cardTransactions.getId()).get();
        // Disconnect from session so that the updates on updatedCardTransactions are not directly saved in db
        em.detach(updatedCardTransactions);
        updatedCardTransactions.builder()
            .txnRefNo(UPDATED_TX_REF)
            .amount(UPDATED_AMOUNT)
            .balance(UPDATED_BALANCE)
            .transactionType(UPDATED_TRANSACTION_TYPE)
            .crdr(UPDATED_TYPE)
            .transactionDateTime(UPDATED_TIME)
            .beneficiaryName(UPDATED_BENEFICIARY_NAME)
            .beneficiaryType(UPDATED_BENEFICIARY_TYPE)
            .beneficiaryId(UPDATED_BENEFICIARY_ID)
            .description(UPDATED_DESCRIPTION)
            .txnOrigin(UPDATED_TXN_ORIGIN)
            .otherPartyName(UPDATED_OTHER_PARTY_NAME)
            .otherPartyId(UPDATED_OTHER_PARTY_ID)
            .txnStatus(UPDATED_TRANSACTION_STATUS)
            .customerWallet(UPDATED_YOUR_WALLET)
            .beneficiaryWallet(UPDATED_BENEFICIARY_WALLET)
            .extTxnId(UPDATED_EXTERNAL_TRANSACTION_ID)
            .retrievalRefNo(UPDATED_RETRIVAL_REFERENCE_NO)
            .authCode(UPDATED_AUTH_CODE)
            .billRefNo(UPDATED_BILL_REF_NO)
            .bankTid(UPDATED_BANK_TID)
            // .createdBy(UPDATED_CREATED_BY)
            // .createdDt(UPDATED_CREATED_DT)
            // .updatedDt(UPDATED_UPDATED_DT)
            // .updatedBy(UPDATED_UPDATED_BY)
            .cardTransactionsAddnInfo(UPDATED_CARD_TRANSACTIONS_ADDN_INFO_ID).build();
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(updatedCardTransactions);

        restCardTransactionsMockMvc
            .perform(
                put(ENTITY_API_URL_ID, cardTransactionsDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isOk());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
        CardTransactions testCardTransactions = cardTransactionsList.get(cardTransactionsList.size() - 1);
        assertThat(testCardTransactions.getTxnRefNo()).isEqualTo(UPDATED_TX_REF);
        assertThat(testCardTransactions.getAmount()).isEqualTo(UPDATED_AMOUNT);
        assertThat(testCardTransactions.getBalance()).isEqualTo(UPDATED_BALANCE);
        assertThat(testCardTransactions.getTransactionType()).isEqualTo(UPDATED_TRANSACTION_TYPE);
        assertThat(testCardTransactions.getCrdr()).isEqualTo(UPDATED_TYPE);
        assertThat(testCardTransactions.getTransactionDateTime()).isEqualTo(UPDATED_TIME);
        assertThat(testCardTransactions.getBeneficiaryName()).isEqualTo(UPDATED_BENEFICIARY_NAME);
        assertThat(testCardTransactions.getBeneficiaryType()).isEqualTo(UPDATED_BENEFICIARY_TYPE);
        assertThat(testCardTransactions.getBeneficiaryId()).isEqualTo(UPDATED_BENEFICIARY_ID);
        assertThat(testCardTransactions.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testCardTransactions.getTxnOrigin()).isEqualTo(UPDATED_TXN_ORIGIN);
        assertThat(testCardTransactions.getOtherPartyName()).isEqualTo(UPDATED_OTHER_PARTY_NAME);
        assertThat(testCardTransactions.getOtherPartyId()).isEqualTo(UPDATED_OTHER_PARTY_ID);
        assertThat(testCardTransactions.getTxnStatus()).isEqualTo(UPDATED_TRANSACTION_STATUS);
        assertThat(testCardTransactions.getCustomerWallet()).isEqualTo(UPDATED_YOUR_WALLET);
        assertThat(testCardTransactions.getBeneficiaryWallet()).isEqualTo(UPDATED_BENEFICIARY_WALLET);
        assertThat(testCardTransactions.getExtTxnId()).isEqualTo(UPDATED_EXTERNAL_TRANSACTION_ID);
        assertThat(testCardTransactions.getRetrievalRefNo()).isEqualTo(UPDATED_RETRIVAL_REFERENCE_NO);
        assertThat(testCardTransactions.getAuthCode()).isEqualTo(UPDATED_AUTH_CODE);
        assertThat(testCardTransactions.getBillRefNo()).isEqualTo(UPDATED_BILL_REF_NO);
        assertThat(testCardTransactions.getBankTid()).isEqualTo(UPDATED_BANK_TID);
        assertThat(testCardTransactions.getCreatedBy()).isEqualTo(UPDATED_CREATED_BY);
        assertThat(testCardTransactions.getCreatedDt()).isEqualTo(UPDATED_CREATED_DT);
        // assertThat(testCardTransactions.getUpdatedDt()).isEqualTo(UPDATED_UPDATED_DT);
        // assertThat(testCardTransactions.getUpdatedBy()).isEqualTo(UPDATED_UPDATED_BY);
        assertThat(testCardTransactions.getCardTransactionsAddnInfo()).isEqualTo(UPDATED_CARD_TRANSACTIONS_ADDN_INFO_ID);
    }

    @Test
    @Transactional
    void putNonExistingCardTransactions() throws Exception {
        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();
        cardTransactions.setId(count.incrementAndGet());

        // Create the CardTransactions
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restCardTransactionsMockMvc
            .perform(
                put(ENTITY_API_URL_ID, cardTransactionsDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchCardTransactions() throws Exception {
        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();
        cardTransactions.setId(count.incrementAndGet());

        // Create the CardTransactions
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restCardTransactionsMockMvc
            .perform(
                put(ENTITY_API_URL_ID, count.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamCardTransactions() throws Exception {
        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();
        cardTransactions.setId(count.incrementAndGet());

        // Create the CardTransactions
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restCardTransactionsMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateCardTransactionsWithPatch() throws Exception {
        // Initialize the database
        cardTransactionsRepository.saveAndFlush(cardTransactions);

        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();

        // Update the cardTransactions using partial update
        CardTransactions partialUpdatedCardTransactions = new CardTransactions();
        partialUpdatedCardTransactions.setId(cardTransactions.getId());

        partialUpdatedCardTransactions.builder()
            .txnRefNo(UPDATED_TX_REF)
            .amount(UPDATED_AMOUNT)
            .transactionDateTime(UPDATED_TIME)
            .beneficiaryName(UPDATED_BENEFICIARY_NAME)
            .beneficiaryType(UPDATED_BENEFICIARY_TYPE)
            .beneficiaryId(UPDATED_BENEFICIARY_ID)
            .description(UPDATED_DESCRIPTION)
            .txnOrigin(UPDATED_TXN_ORIGIN)
            .otherPartyName(UPDATED_OTHER_PARTY_NAME)
            .beneficiaryWallet(UPDATED_BENEFICIARY_WALLET)
            .retrievalRefNo(UPDATED_RETRIVAL_REFERENCE_NO)
            .authCode(UPDATED_AUTH_CODE)
            .billRefNo(UPDATED_BILL_REF_NO)
            // .createdDt(UPDATED_CREATED_DT)
            // .updatedBy(UPDATED_UPDATED_BY)
            .cardTransactionsAddnInfo(UPDATED_CARD_TRANSACTIONS_ADDN_INFO_ID).build();

        restCardTransactionsMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedCardTransactions.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedCardTransactions))
            )
            .andExpect(status().isOk());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
        CardTransactions testCardTransactions = cardTransactionsList.get(cardTransactionsList.size() - 1);
        assertThat(testCardTransactions.getTxnRefNo()).isEqualTo(UPDATED_TX_REF);
        assertThat(testCardTransactions.getAmount()).isEqualTo(UPDATED_AMOUNT);
        assertThat(testCardTransactions.getBalance()).isEqualTo(DEFAULT_BALANCE);
        assertThat(testCardTransactions.getTransactionType()).isEqualTo(DEFAULT_TRANSACTION_TYPE);
        assertThat(testCardTransactions.getCrdr()).isEqualTo(DEFAULT_TYPE);
        assertThat(testCardTransactions.getTransactionDateTime()).isEqualTo(UPDATED_TIME);
        assertThat(testCardTransactions.getBeneficiaryName()).isEqualTo(UPDATED_BENEFICIARY_NAME);
        assertThat(testCardTransactions.getBeneficiaryType()).isEqualTo(UPDATED_BENEFICIARY_TYPE);
        assertThat(testCardTransactions.getBeneficiaryId()).isEqualTo(UPDATED_BENEFICIARY_ID);
        assertThat(testCardTransactions.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testCardTransactions.getTxnOrigin()).isEqualTo(UPDATED_TXN_ORIGIN);
        assertThat(testCardTransactions.getOtherPartyName()).isEqualTo(UPDATED_OTHER_PARTY_NAME);
        assertThat(testCardTransactions.getOtherPartyId()).isEqualTo(DEFAULT_OTHER_PARTY_ID);
        assertThat(testCardTransactions.getTxnStatus()).isEqualTo(DEFAULT_TRANSACTION_STATUS);
        assertThat(testCardTransactions.getCustomerWallet()).isEqualTo(DEFAULT_YOUR_WALLET);
        assertThat(testCardTransactions.getBeneficiaryWallet()).isEqualTo(UPDATED_BENEFICIARY_WALLET);
        assertThat(testCardTransactions.getExtTxnId()).isEqualTo(DEFAULT_EXTERNAL_TRANSACTION_ID);
        assertThat(testCardTransactions.getRetrievalRefNo()).isEqualTo(UPDATED_RETRIVAL_REFERENCE_NO);
        assertThat(testCardTransactions.getAuthCode()).isEqualTo(UPDATED_AUTH_CODE);
        assertThat(testCardTransactions.getBillRefNo()).isEqualTo(UPDATED_BILL_REF_NO);
        assertThat(testCardTransactions.getBankTid()).isEqualTo(DEFAULT_BANK_TID);
        assertThat(testCardTransactions.getCreatedBy()).isEqualTo(DEFAULT_CREATED_BY);
        assertThat(testCardTransactions.getCreatedDt()).isEqualTo(UPDATED_CREATED_DT);
        // assertThat(testCardTransactions.getUpdatedDt()).isEqualTo(DEFAULT_UPDATED_DT);
        // assertThat(testCardTransactions.getUpdatedBy()).isEqualTo(UPDATED_UPDATED_BY);
        assertThat(testCardTransactions.getCardTransactionsAddnInfo()).isEqualTo(UPDATED_CARD_TRANSACTIONS_ADDN_INFO_ID);
    }

    @Test
    @Transactional
    void fullUpdateCardTransactionsWithPatch() throws Exception {
        // Initialize the database
        cardTransactionsRepository.saveAndFlush(cardTransactions);

        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();

        // Update the cardTransactions using partial update
        CardTransactions partialUpdatedCardTransactions = new CardTransactions();
        partialUpdatedCardTransactions.setId(cardTransactions.getId());

        partialUpdatedCardTransactions.builder()
            .txnRefNo(UPDATED_TX_REF)
            .amount(UPDATED_AMOUNT)
            .balance(UPDATED_BALANCE)
            .transactionType(UPDATED_TRANSACTION_TYPE)
            .crdr(UPDATED_TYPE)
            .transactionDateTime(UPDATED_TIME)
            .beneficiaryName(UPDATED_BENEFICIARY_NAME)
            .beneficiaryType(UPDATED_BENEFICIARY_TYPE)
            .beneficiaryId(UPDATED_BENEFICIARY_ID)
            .description(UPDATED_DESCRIPTION)
            .txnOrigin(UPDATED_TXN_ORIGIN)
            .otherPartyName(UPDATED_OTHER_PARTY_NAME)
            .otherPartyId(UPDATED_OTHER_PARTY_ID)
            .txnStatus(UPDATED_TRANSACTION_STATUS)
            .customerWallet(UPDATED_YOUR_WALLET)
            .beneficiaryWallet(UPDATED_BENEFICIARY_WALLET)
            .extTxnId(UPDATED_EXTERNAL_TRANSACTION_ID)
            .retrievalRefNo(UPDATED_RETRIVAL_REFERENCE_NO)
            .authCode(UPDATED_AUTH_CODE)
            .billRefNo(UPDATED_BILL_REF_NO)
            .bankTid(UPDATED_BANK_TID)
            // .createdBy(UPDATED_CREATED_BY)
            // .createdDt(UPDATED_CREATED_DT)
            // .updatedDt(UPDATED_UPDATED_DT)
            // .updatedBy(UPDATED_UPDATED_BY)
            .cardTransactionsAddnInfo(UPDATED_CARD_TRANSACTIONS_ADDN_INFO_ID).build();

        restCardTransactionsMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedCardTransactions.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedCardTransactions))
            )
            .andExpect(status().isOk());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
        CardTransactions testCardTransactions = cardTransactionsList.get(cardTransactionsList.size() - 1);
        assertThat(testCardTransactions.getTxnRefNo()).isEqualTo(UPDATED_TX_REF);
        assertThat(testCardTransactions.getAmount()).isEqualTo(UPDATED_AMOUNT);
        assertThat(testCardTransactions.getBalance()).isEqualTo(UPDATED_BALANCE);
        assertThat(testCardTransactions.getTransactionType()).isEqualTo(UPDATED_TRANSACTION_TYPE);
        assertThat(testCardTransactions.getCrdr()).isEqualTo(UPDATED_TYPE);
        assertThat(testCardTransactions.getTransactionDateTime()).isEqualTo(UPDATED_TIME);
        assertThat(testCardTransactions.getBeneficiaryName()).isEqualTo(UPDATED_BENEFICIARY_NAME);
        assertThat(testCardTransactions.getBeneficiaryType()).isEqualTo(UPDATED_BENEFICIARY_TYPE);
        assertThat(testCardTransactions.getBeneficiaryId()).isEqualTo(UPDATED_BENEFICIARY_ID);
        assertThat(testCardTransactions.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testCardTransactions.getTxnOrigin()).isEqualTo(UPDATED_TXN_ORIGIN);
        assertThat(testCardTransactions.getOtherPartyName()).isEqualTo(UPDATED_OTHER_PARTY_NAME);
        assertThat(testCardTransactions.getOtherPartyId()).isEqualTo(UPDATED_OTHER_PARTY_ID);
        assertThat(testCardTransactions.getTxnStatus()).isEqualTo(UPDATED_TRANSACTION_STATUS);
        assertThat(testCardTransactions.getCustomerWallet()).isEqualTo(UPDATED_YOUR_WALLET);
        assertThat(testCardTransactions.getBeneficiaryWallet()).isEqualTo(UPDATED_BENEFICIARY_WALLET);
        assertThat(testCardTransactions.getExtTxnId()).isEqualTo(UPDATED_EXTERNAL_TRANSACTION_ID);
        assertThat(testCardTransactions.getRetrievalRefNo()).isEqualTo(UPDATED_RETRIVAL_REFERENCE_NO);
        assertThat(testCardTransactions.getAuthCode()).isEqualTo(UPDATED_AUTH_CODE);
        assertThat(testCardTransactions.getBillRefNo()).isEqualTo(UPDATED_BILL_REF_NO);
        assertThat(testCardTransactions.getBankTid()).isEqualTo(UPDATED_BANK_TID);
        assertThat(testCardTransactions.getCreatedBy()).isEqualTo(UPDATED_CREATED_BY);
        assertThat(testCardTransactions.getCreatedDt()).isEqualTo(UPDATED_CREATED_DT);
        // assertThat(testCardTransactions.getUpdatedDt()).isEqualTo(UPDATED_UPDATED_DT);
        // assertThat(testCardTransactions.getUpdatedBy()).isEqualTo(UPDATED_UPDATED_BY);
        assertThat(testCardTransactions.getCardTransactionsAddnInfo()).isEqualTo(UPDATED_CARD_TRANSACTIONS_ADDN_INFO_ID);
    }

    @Test
    @Transactional
    void patchNonExistingCardTransactions() throws Exception {
        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();
        cardTransactions.setId(count.incrementAndGet());

        // Create the CardTransactions
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restCardTransactionsMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, cardTransactionsDTO.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchCardTransactions() throws Exception {
        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();
        cardTransactions.setId(count.incrementAndGet());

        // Create the CardTransactions
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restCardTransactionsMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, count.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamCardTransactions() throws Exception {
        int databaseSizeBeforeUpdate = cardTransactionsRepository.findAll().size();
        cardTransactions.setId(count.incrementAndGet());

        // Create the CardTransactions
        CardTransactionsDTO cardTransactionsDTO = cardTransactionsMapper.toDto(cardTransactions);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restCardTransactionsMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(cardTransactionsDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the CardTransactions in the database
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteCardTransactions() throws Exception {
        // Initialize the database
        cardTransactionsRepository.saveAndFlush(cardTransactions);

        int databaseSizeBeforeDelete = cardTransactionsRepository.findAll().size();

        // Delete the cardTransactions
        restCardTransactionsMockMvc
            .perform(delete(ENTITY_API_URL_ID, cardTransactions.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<CardTransactions> cardTransactionsList = cardTransactionsRepository.findAll();
        assertThat(cardTransactionsList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
