package com.zaggle.xpns.transactions.arch;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.lang.ArchRule;

@RunWith(JUnit4.class)
public class NamingConventionTests {

//	@Test
//	public void api_resource_should_be_suffixed() {
//
//		JavaClasses importedClasses = new ClassFileImporter()
//				.withImportOption(new com.tngtech.archunit.core.importer.ImportOption.DoNotIncludeTests())
//				.importPackages("com.zaggle.xpns.transactions.web.rest");
//
//		ArchRule restNamingRule = classes().that().resideInAPackage("..web.rest").should()
//				.haveSimpleNameEndingWith("ApiResource").andShould().notHaveSimpleName("Controller");
//
//		restNamingRule.check(importedClasses);
//	}
}
