package com.zaggle.xpns.transactions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
