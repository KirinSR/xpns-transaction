package com.zaggle.xpns.transactions.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.zaggle.xpns.transactions.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class CardTransactionAddnInfoDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
//        TestUtil.equalsVerifier(CardTransactionAddnInfoDTO.class);
//        CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO1 = new CardTransactionAddnInfoDTO();
//        cardTransactionAddnInfoDTO1.setId(1L);
//        CardTransactionAddnInfoDTO cardTransactionAddnInfoDTO2 = new CardTransactionAddnInfoDTO();
//        assertThat(cardTransactionAddnInfoDTO1).isNotEqualTo(cardTransactionAddnInfoDTO2);
//        cardTransactionAddnInfoDTO2.setId(cardTransactionAddnInfoDTO1.getId());
//        assertThat(cardTransactionAddnInfoDTO1).isEqualTo(cardTransactionAddnInfoDTO2);
//        cardTransactionAddnInfoDTO2.setId(2L);
//        assertThat(cardTransactionAddnInfoDTO1).isNotEqualTo(cardTransactionAddnInfoDTO2);
//        cardTransactionAddnInfoDTO1.setId(null);
//        assertThat(cardTransactionAddnInfoDTO1).isNotEqualTo(cardTransactionAddnInfoDTO2);
    }
}
