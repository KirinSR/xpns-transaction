package com.zaggle.xpns.transactions.domain;

import static org.assertj.core.api.Assertions.assertThat;

import com.zaggle.xpns.transactions.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class CardTransactionsTest {

    @Test
    void equalsVerifier() throws Exception {
//        TestUtil.equalsVerifier(CardTransactions.class);
        CardTransactions cardTransactions1 = new CardTransactions();
        cardTransactions1.setId(1L);
        CardTransactions cardTransactions2 = new CardTransactions();
        cardTransactions2.setId(cardTransactions1.getId());
        assertThat(cardTransactions1).isEqualTo(cardTransactions2);
        cardTransactions2.setId(2L);
        assertThat(cardTransactions1).isNotEqualTo(cardTransactions2);
        cardTransactions1.setId(null);
        assertThat(cardTransactions1).isNotEqualTo(cardTransactions2);
    }
}
