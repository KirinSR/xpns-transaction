## Getting Started

### Reference Documentation[WIP]

## Pre-requisite
*  Java 11 +
*  Maven 3 + 
 
## Extract the zip & go to root folder

*	$ mvn spring-boot:run 

## Access Hello API
* http://localhost:8187/api/hello-expense-apis


## Access API Doc Specification

* http://localhost:8187/v3/api-docs

## Access Swagger UI  

* http://localhost:8187/transactions/swagger-ui/index.html


  
## Build Docker Image

* mvnw package -Pdev jib:dockerBuild -Dmaven.test.skip=true```



### Guides
The following guides illustrate how to use some features concretely:



=======
# transactions
